package org.cap.demo;

public class Test {
	//instance variable
	int count;
	char ch;
	boolean flag;
	byte num;
	float pi;

	public static void main(String[] args) {
		
		
		int mynum=800; 
		
		Test obj= new Test();
		obj.num=23;
		System.out.println(obj.ch);
		System.out.println(obj.flag);
		System.out.println(obj.count);
		System.out.println(obj.num);
		System.out.println(obj.pi);
		
		System.out.println("mynum="+mynum);


	}

}
