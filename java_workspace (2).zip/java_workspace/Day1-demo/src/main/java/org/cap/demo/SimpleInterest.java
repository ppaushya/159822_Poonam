package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {
	
	double principle;
	float years;
	float rateOfInterest;
	
	public void getData()
	{
		
		principle=4000;
		years=3.3f;
		rateOfInterest=0.0665f;
		
		Scanner scanner = new Scanner (System.in);
		System.out.println("enter principle:");
		principle=scanner.nextDouble();
		
		System.out.println("enter years:");
		years=scanner.nextFloat();
		
		System.out.println("enter rateOfInterest:");
		rateOfInterest=scanner.nextFloat();
		
		scanner.close();
		
	}
	
	public double calculateInterest() 
	{
		return principle*years*rateOfInterest;
	}
	public static void main (String[] args) {

		SimpleInterest interest= new SimpleInterest();
		interest.getData();
		double simpleinterest=interest.calculateInterest();
		System.out.println("Calculates interest is"+simpleinterest);
		
	}
	


}
