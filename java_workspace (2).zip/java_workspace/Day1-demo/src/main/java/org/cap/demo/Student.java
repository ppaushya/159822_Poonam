package org.cap.demo;

import java.util.Scanner;

public class Student {
	
	String name;
	int mark1, mark2, mark3;
	int score;
	int avg;
	
	
	public void getStudent() {
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("Enter Name");
		name= scan.next();
		System.out.println("Enter mark1");
		mark1= scan.nextInt();
		System.out.println("Enter mark2");
		mark2= scan.nextInt();
		System.out.println("Enter mark3");
		mark3= scan.nextInt();
		
		scan.close();
	}
	
	public int findScore() {
		
		score=mark1+mark2+mark3;
		return score;
	}
	
	public float findAverage() {
		
		avg=(mark1+mark2+mark3)/3;
		return avg;
	}
	
	public void printStudent() {
		
		System.out.println("Name:"+name);
		System.out.println("mark1:"+mark1);
		System.out.println("mark2:"+mark2);
		System.out.println("mark3:"+mark3);
		System.out.println("score:"+score);
		System.out.println("average:"+avg);
		
	}

	public static void main(String[] args) {
		
		Student s= new Student();
		s.getStudent();
		s.findScore();
		s.findAverage();
		s.printStudent();
	}

}
