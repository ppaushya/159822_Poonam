package org.cap.demo;

import java.util.Scanner;

public class Employee {
	
	
	int empId;
	String empName =new String();
	int age;
	boolean isPermanent;
	char gender;
	String address=new String();
	
	public void getEmployee(){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter empId");
		empId= scan.nextInt();
		System.out.println("Enter empName");
		empName= scan.next();
		System.out.println("Enter age");
		age= scan.nextInt();
		System.out.println("Enter isPermanent");
		isPermanent= scan.nextBoolean();
		System.out.println("Enter gender");
		gender= scan.next().charAt(0);
		System.out.println("Enter address");
		address= scan.next();
		scan.close();
		
	}
	
	public void printEmployee() {
		
		System.out.println("empId:"+empId);
		System.out.println("empName:"+empName);
		System.out.println("age:"+age);
		System.out.println("isPermanent:"+isPermanent);
		System.out.println("gender:"+gender);
		System.out.println("address:"+address);

		
	}

	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.getEmployee();
		e.printEmployee();
	}

}
