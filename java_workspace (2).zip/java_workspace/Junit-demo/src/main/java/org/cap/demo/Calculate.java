package org.cap.demo;

public class Calculate {

	public int addNumber(int i, int j)
	{
		return i+j;
		
	}
	public long runLoop() {
		long sum=0;
		for(long i=0;i<453624623;i++)
			sum++;
		return sum;
	}

	
	
}

