package org.cap.account.test;

import static org.junit.Assert.*;

import org.cap.account.dao.IAccountDao;
import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Address;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class TestAccount {
	
	
	@Mock
	private IAccountDao accountDao;

	@BeforeClass
	public static void beforeClass()
	{
		System.out.println("Before class method");
	}
	@AfterClass
	public static void afterClass()
	{
		System.out.println("Before class method");
	}
	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
		AccountServiceImpl accountService = new AccountServiceImpl();
	}
	
	@Test
	public void test_add_account() {
		
		IAccountService accountService =new AccountServiceImpl();
	}

	@Test(expected=IllegalArgumentException.class)
	public void when_create_account_with_null_customer() throws IllegalArgumentException, InvalidAmountException{
		Customer customer=null;
		IAccountService accountService=new AccountServiceImpl();
		accountService.createAccount(customer, 1000);
	}
	
	@Test(expected=InvalidAmountException.class)
	public void when_create_account_with_insufficient_amount() throws InvalidAmountException{
		Customer customer=new Customer(123, "Madhu", new Address(), new Account());
		IAccountService accountService=new AccountServiceImpl();
		accountService.createAccount(customer, 500);
	}
	 
 

}
