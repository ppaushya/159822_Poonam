package org.cap.account.model;

public class Address {

	private String addressLine;

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public Address() {
		
	}
	@Override
	public String toString() {
		return "Addresss [addressLine=" + addressLine + "]";
	}

	public Address(String addressLine) {
		super();
		this.addressLine = addressLine;
	}
	
	
}
