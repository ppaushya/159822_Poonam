package org.cap.loop.demo;

public class ForDemo {

	public static void main(String[] args) {
		int i;
		for(i=1;i<=4;i++) {
			for(int j=1;j<=4;j++) {
				if(j>=i) {
					System.out.print("*\t");
				}
				else
					System.out.print("\t");

				}
			System.out.println("\n");
			}
		

		}

	}

