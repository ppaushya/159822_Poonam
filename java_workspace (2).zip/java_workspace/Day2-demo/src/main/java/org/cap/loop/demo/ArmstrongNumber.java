package org.cap.loop.demo;

public class ArmstrongNumber {

	public static void main(String[] args) {
		int j=1;
		int sum=0;
		int rem=0;
		for(int i=1;i<=1000;i++)
		{
			j=i;
			while(j>0)
			{
				rem=j%10;
				sum=rem*rem*rem+sum;
				j=j/10;
			}
			
			if(sum==i)
				System.out.print(i+" ");
			sum=0;
		}

	}

}
