package org.cap.loop.demo;

import java.util.Scanner;

public class Assignment {
	

	public static void main(String[] args) {
		
		int num,count=1,x=1,y=2;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the number:");
		num=s.nextInt();
		while(count<=num)
		{
			for(int i=1;i<=3;i++)
				{
					System.out.print(x+" ");
					x+=2;
					count++;
					if(count==num)
						break;
				}
			if(count==num)
				break;
				for(int i=1;i<=3;i++)
				{
					System.out.print(y+" ");
					count++;
					y+=2;
					if(count==num)
						break;
				}
				if(count==num)
					break;
				
			}

		s.close();

	}
}