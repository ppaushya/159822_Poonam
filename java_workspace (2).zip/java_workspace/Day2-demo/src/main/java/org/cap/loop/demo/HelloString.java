package org.cap.loop.demo;


import java.util.Scanner;
import java.lang.String;

public class HelloString {

	public static void main(String[] args) {
		
		Scanner s= new Scanner(System.in);
		
		String name;
		name=s.nextLine();
		
		int l;
		l=name.length();
		
		for(int i=0;i<l;i++)
		{
			for(int j=0;j<i;j++)
			{
				System.out.printf("%c", name.charAt(j));
			}
			System.out.printf("%c\n",name.charAt(i));
		}
		
		
		
		
		s.close();

	}

}


