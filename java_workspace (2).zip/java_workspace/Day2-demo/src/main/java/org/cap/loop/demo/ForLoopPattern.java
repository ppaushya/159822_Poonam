package org.cap.loop.demo;

public class ForLoopPattern {

	public static void main(String[] args) {
		int i,j,count=1;
		for (i=0;i<5;i++) {
			for(j=0;j<i;j++) {
				
				
				if(i>=j) {
					System.out.print(count+"\t");
					++count;
				}
				
			}
			System.out.print("\n");
		}
		
	}

}
