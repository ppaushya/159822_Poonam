package org.cap.loop.demo;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
	
		int num,y=0;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the number:");
		num=s.nextInt();
		
		while(num>10)
		{
			y=num%10+y;
			num=num/10;
			
		}
		y=y+num;
		System.out.print(y);
	}

}
