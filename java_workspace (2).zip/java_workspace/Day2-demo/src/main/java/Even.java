
public class Even {
	
	
	public static void main(String[] args) {
		int count=5;
		int num=0;
		for(int i=1 ;i<=100;i++ )
		{
			if(i%2==0 && count==5) {
				num=num+i;
				System.out.print(i+" ");
				count--;		
			}
			else if(i%2==0 && count<5)
			{
				num=num+i;
				System.out.print(" * ");
				count--;	
				if(count==0)
				{
					count=5;
					System.out.println(" ");
				}
			}
			
			if(count==0)
			{	
				count=5;
				System.out.println(" * ");
			}
				
		}
		
		System.out.println(num);
	}

}
