import java.util.Scanner;

public class Product {
	
	String productName;
	int productId;
	int quantity;
	float price;
	float discount;
	float tax;
	float discountInRs;
	float finalPrice;
	
	public void getProductDetails() {
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter product name:");
		productName= s.next();
		System.out.println("Enter product Id:");
		productId= s.nextInt();
		System.out.println("Enter quantity:");
		quantity= s.nextInt();
		System.out.println("Enter price:");
		price= s.nextInt();
		System.out.println("Enter discount in percentage:");
		discount= s.nextFloat();
		
		s.close();
	}
	
	public float calculateTax() {
		
		if(discount>90)
			tax=0.01f*price;
		else if(discount>80 && discount<90)
			tax=0.12f*price;
		else if(discount>60 && discount<80)
			tax=0.20f*price;
		else if(discount>50 && discount<60)
			tax=0.25f*price;
		else if(discount<50)
			tax=0.4f*price;
		
		return tax;
	}
	
	
	public float calculateDiscount() {
		
		discountInRs=price*discount/100;
		
		return discountInRs;
	}
	
	public float calculateFinalPrice() {
		
		price= price+tax-discountInRs;
		return 	price;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Product p=new Product();
		p.getProductDetails();
		p.calculateTax();
		p.calculateDiscount();
		p.finalPrice= p.calculateFinalPrice();
		System.out.println("Final price is:"+p.finalPrice*p.quantity);

	}

}
