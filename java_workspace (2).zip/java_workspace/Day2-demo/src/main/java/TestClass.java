
public class TestClass {
	
	public void testIf(int num) {
		if(num>0)
			System.out.println("Positive");
		else if(num<0)
			System.out.println("Negative");
		else
			System.out.println("Zero");


	}

	public static void main(String[] args) {
		TestClass class1= new TestClass();
		class1.testIf(0);
	}

}
