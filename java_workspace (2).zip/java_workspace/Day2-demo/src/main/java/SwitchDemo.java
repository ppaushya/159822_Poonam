
public class SwitchDemo {

	public static void main(String[] args) {
		
		String a="name";
		
		switch (a) 
		{
		
			case "name":{
				System.out.println("one");
				System.out.println("Block");
				break;
			}
			case "poonam":{
				System.out.println("TWO");
				break;

			}
			case "hi":{
				System.out.println("ten");
				break;

			}
			default:
				System.out.println("Default Block");


		}

	}

}
