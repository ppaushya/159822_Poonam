import java.util.Scanner;

public class Que5 {
	
	String name,a,b;
	String reverse="";
	
	public String getElements()
	{
		Scanner s = new Scanner (System.in);
		System.out.println("Enter the string");
		name=s.nextLine();
		s.close();
		return name;
	}
	
	public String reverseString(String a)
	{
		for(int i=0;i<a.length();i++)
		{
			reverse=reverse+name.charAt(a.length()-i-1);
			
				
		}
		return reverse;
	}

	public static void main(String[] args) {
		
		Que5 q= new Que5();
		
		q.a=q.getElements();
		q.b=q.reverseString(q.a);
		System.out.println(q.b);


	}

}
