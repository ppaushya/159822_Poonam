package Balance;

public class Account {

	public void DisplayBalance() {
		System.out.println("balance");
	}
	
	public static void main(String[] args) {
		

	}

}
