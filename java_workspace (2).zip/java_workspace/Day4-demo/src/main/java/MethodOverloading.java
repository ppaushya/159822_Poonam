
public class MethodOverloading {
	
	int principle;
	int yr;
	double rate;
	double si;
	
	public MethodOverloading()
	{
		principle=10000;
		yr=5;
		rate=0.05;
	}
	
	public double simpleInterest() {
		si=principle*rate*yr;
		return si;
	}
	public double simpleInterest(int p) {
		si=p*rate*yr;
		return si;
	}
	public double simpleInterest(int p, int y) {
		si=p*rate*y;
		return si;
	}
	public double simpleInterest(int p, int y,double r) {
		si=p*r*y;
		return si;
	}
	

	public static void main(String[] args) {
		
		MethodOverloading m=new MethodOverloading();
		double a=m.simpleInterest();
		double b=m.simpleInterest(20000);
		double c=m.simpleInterest(20000,6);
		double d=m.simpleInterest(20000,6,0.1);
		System.out.println(a+" "+b+" "+c+" "+d);
		

	}

}
