import java.util.Scanner;

public class Que2 {
	
	String str,str1,mystr="";
	
	public String alphabetSoup(String str)
	{
		char[] swap=new char[str.length()];
		
		for(int i=0;i<str.length();i++)
		{
			swap[i]=str.charAt(i);
		}
		
		for(int i=0;i<str.length();i++)
		{
			for(int j=i;j<str.length();j++)
			{
				if(swap[i]>swap[j])
				{
					char temp= swap[i];
					swap[i]=swap[j];
					swap[j]=temp;
				}
			}
		}
		for(int i=0;i<str.length();i++)
		{
			mystr=mystr+swap[i];
		}
		
		return mystr;
	}

	public static void main(String[] args) {
		
		Que2 q= new Que2();
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the string");
		q.str=s.next();
		s.close();
		q.str1=q.alphabetSoup(q.str);
		System.out.println(" string in alphabetical order is: "+q.str1);
		

	}

}
