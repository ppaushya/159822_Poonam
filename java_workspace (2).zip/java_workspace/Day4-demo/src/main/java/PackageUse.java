import Balance.Account;
public class PackageUse {

	public static void main(String[] args) {
		Account a=new Account();
		a.DisplayBalance();

	}

}
