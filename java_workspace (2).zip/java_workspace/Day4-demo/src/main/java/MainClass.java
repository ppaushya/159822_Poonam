
public class MainClass {

	public static void main(String[] args) {
		Weekdays myDay= Weekdays.MON;
		switch(myDay) {
		
		case SUN: System.out.print("Holiday");
			break;
		case MON: System.out.print("MON");
		break;
		case TUE: System.out.print("TUEy");
		break;
		case WED: System.out.print("WED");
		break;
		case THU: System.out.print("THU");
		break;
		case FRI: System.out.print("FRI");
		break;
		case SAT: System.out.print("SAT");
		break;
		default:
			System.out.print("Special Day");
			break;
		}

	}

}
