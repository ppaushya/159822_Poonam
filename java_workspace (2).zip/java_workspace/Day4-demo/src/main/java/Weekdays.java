
public enum Weekdays {
	
	SUN(0),MON(1),TUE(2),WED(3),THU(4),FRI(5),SAT(6);
	
	int value;//instance variable according to enum
	
	//enum constructor is private and cannot be accessed outside the class
	private Weekdays(int var)
	{
		this.value=var;
	}
	//public means can be accessed outside
	public int getValue()
	{
		return this.value;
	}

}
