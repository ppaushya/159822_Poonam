
public class NewClass {

	public static void main(String[] args) {
		String str="tom";
		String mystr= new String ("tom");
		String mystr1= new String ("tom");

		System.out.println(str==mystr);
		System.out.println(mystr==mystr1);

		System.out.println(str.equals(mystr));
		System.out.println(mystr.equals(mystr1));




	}

}
