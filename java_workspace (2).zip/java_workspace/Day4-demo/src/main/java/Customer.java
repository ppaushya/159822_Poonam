	enum CustomerType
	{
		SILVER(0,100), GOLD(100,200), DIAMOND(200,300),PLATINUM(300,400), ;
		
		int minrewardPoints;
		int maxrewardPoints;

		
		private CustomerType (int minrewardPoints,int maxrewardPoints) {
			this.minrewardPoints= minrewardPoints;
			this.maxrewardPoints= maxrewardPoints;

		}
		public int getMaxRewardPoints()
		{
			return this.maxrewardPoints;
		}
		public int getMinRewardPoints()
		{
			return this.minrewardPoints;
		}
	}
	
public class Customer {
	
	String customerName="jack";
	int Id=1001;
	CustomerType customerType=CustomerType.DIAMOND;


	public static void main(String[] args) {

		Customer c= new Customer();
		System.out.print(c.customerName+" "+c.Id+ " "+c.customerType+" "+c.customerType.getMaxRewardPoints()+" "+c.customerType.getMinRewardPoints());

	}

}
