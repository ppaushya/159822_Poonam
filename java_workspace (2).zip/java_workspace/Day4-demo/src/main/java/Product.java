
public class Product {
	
	int productId;
	String productName;
	double price;
	int qty;
	
	public void printProduct()
	{
		System.out.println("["+productId+ " "+ productName+" "+price+" "+qty);

	}
	
	public Product()
	{
		System.out.println("Default constructor");
	}
	
	public Product(int prodId)
	{
		System.out.println("Overloaded constructor");
		this.productId=prodId;
	}
	
	public static void main(String[] args) {
	
		Product p=new Product();//call default constructor
	
		System.out.println(p);
		p.printProduct();
		
		Product p1=new Product(1001);
		System.out.println(p1);
		p1.printProduct();

	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + ", qty=" + qty
				+ "]";
	}

}
