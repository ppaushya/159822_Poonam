import java.util.Scanner;

public class Employee {
	
	int empId;
	String firstName;
	String lastName;
	int age;
	int salary;
	Weekdays weekOff;
	int myDay;
	
	public void getEmployee() {
		
		empId=1001;
		firstName="tom";
		lastName="sinngh";
		age=36;
		salary=36000;
		//weekOff=Weekdays.SAT;
		Scanner s=new Scanner(System.in);
		System.out.print("enter the weekday[1-7]:\n MON-1\nTUE-2\nWED-3\nTHU-4\nFRI-5\nSAT-6\nSUN-7");
		
		myDay=s.nextInt();
		s.close();
		
switch(myDay) {
		
		case 1: weekOff=Weekdays.MON;
			break;
		case 2:  weekOff=Weekdays.TUE;
			break;
		case 3:  weekOff=Weekdays.WED;
			break;
		case 4:  weekOff=Weekdays.THU;
			break;
		case 5:  weekOff=Weekdays.FRI;
			break;
		case 6:  weekOff=Weekdays.SAT;
			break;
		case 7:  weekOff=Weekdays.SUN;
			break;
		}
		
	}

	public void printEmployee() {
		System.out.print(empId+" "+firstName+" "+lastName + " " +age+" "+ salary+" "+weekOff+" "+weekOff.getValue());

	}
	public static void main(String[] args) {

		Employee e= new Employee ();
		e.getEmployee();
		e.printEmployee();
		

	}

}
