import java.util.Arrays;

public class TestClass {

	public static void main(String[] args) {

		int[] arr= {74,124,567,13,6};
		Arrays.sort(arr);
		for(int i=0;i<5;i++)
			System.out.println(arr[i]);

		String[] name= {"tom","harry","jack"};
		Arrays.sort(name);
		
		for(int i=0;i<3;i++)
			System.out.println(name[i]);
		
		System.out.print(" ");
	}

}
