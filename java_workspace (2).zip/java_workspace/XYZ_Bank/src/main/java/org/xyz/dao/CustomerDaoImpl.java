package org.xyz.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.xyz.modal.Account;
import org.xyz.modal.Address;
import org.xyz.modal.Customer;

public class CustomerDaoImpl implements ICustomerDao {

	public static List<Customer> customers= dummyDb();
	
	Set<Account> accounts= new HashSet<>();
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	private static List<Customer> dummyDb() {

		List<Customer> customers= new ArrayList<>();
		
		customers.add(new Customer(1,"poonam","ojha","poonamojha96@gmail.com","9915155124",
				LocalDate.of(1996, 10, 11),new Address("H.No.1945 St.No.14","Dashmesh Nagar","Ludhiana","Punjab",141003)));
		customers.add(new Customer(3,"tom","singh","tomsingh6@gmail.com","8842326213",
				LocalDate.of(1995, 10, 1),new Address("H.No.132","Uncha Thok","Hardoi","UP",240001)));
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		customers.add(customer);
		System.out.println(customer);
		
	}

	@Override
	public void createAccount(Account account) {
		
		accounts.add(account);
		System.out.println(account);
		
		
	}

	@Override
	public Set<Account> getAllAccounts(Customer customer) {
		
		
		return accounts;
	}

	
	
}
