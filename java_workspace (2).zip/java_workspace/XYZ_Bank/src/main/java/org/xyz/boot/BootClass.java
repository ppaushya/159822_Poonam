package org.xyz.boot;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.xyz.modal.Account;
import org.xyz.modal.Customer;
import org.xyz.service.CustomerServiceImpl;
import org.xyz.service.ICustomerService;
//import org.xyz.service.ICustomerService;
import org.xyz.view.UserInteraction;

public class BootClass {

	private static List<Customer> customer;

	static Scanner scan= new Scanner(System.in);
	
	public static void main(String[] args) {
		
		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction= new UserInteraction();
		char c;
		int option;
		
		
		do {
			System.out.println("1.Create Customer");
			System.out.println("2.List Customers");
			System.out.println("Enter Your choice:");
			int choice=scan.nextInt();
			System.out.println(choice);
			if(choice==1)
			{
				Customer customer;
				int count=customerService.getAllCustomers().size();
				customer=userInteraction.getCustomerDetails();
				
				customerService.createCustomer(customer);
				
				
				if(count==customerService.getAllCustomers().size())
					userInteraction.printError("Customer Creation Error! Please Try Again!");
				
			}
			else if(choice==2)
			{
				List<Customer> customers;
				customers=customerService.getAllCustomers();
				userInteraction.printCustomerDetails(customers);
			}
			else
				System.out.println("Enter a valid choice");
			
			
			System.out.println("Do you want to add another customer[y/n]");
			c=scan.next().charAt(0);
		}while(c=='y'||c=='Y');
		
		Customer customer;
		do {
		System.out.println("Enter the customer id of the required customer:");
		int customerId=scan.nextInt();
		customer=customerService.findCustomerId(customerId);
		
			
			if(customer!=null)
			{
				System.out.println("1. Create Account");
				System.out.println("2. Print Customer Details with Account info");
				System.out.println("3. Do Transaction");
		        System.out.println("4. Transaction Summary");
				System.out.println("Enter your Choice[1,2,3,4]?");
				option=scan.nextInt();
				if(option==1)
				{
					Account account;
					
					account=userInteraction.getAccountDetails(customer);
					
					customerService.createAccount(account);
				}
				else if(option==2)
				{
					Set<Account> accounts=new HashSet<>();
					accounts=customerService.getAllAccounts(customer);
					userInteraction.printAccountDetails(accounts);
				}
				else if(option==3)
				{
					
				}
				else if(option==4)
				{
					
				}
				else
					System.out.println("Sorry! Invalid choice. Please try Again!");
			}
			else
				System.out.println("Enter a valid customer id");
		}while(customer==null);
		
			
		
		
		

	}

}
