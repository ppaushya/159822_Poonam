package org.xyz.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.xyz.dao.CustomerDaoImpl;
import org.xyz.dao.ICustomerDao;
import org.xyz.modal.Account;
import org.xyz.modal.Customer;

public class CustomerServiceImpl implements ICustomerService {

	ICustomerDao customerDao= new CustomerDaoImpl();
	
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.getAllCustomers();
	}

	@Override
	public void createCustomer(Customer customer) {
		
		if(isValidCustomer(customer))
			customerDao.createCustomer(customer);
		
		
		
	}

	private boolean isValidCustomer(Customer customer) {
		
		boolean flag=false;
		
		if(customer.getMobileNo().matches("(9|8|7)\\d{9}"))
			if(customer.getDateOfBirth().isBefore(LocalDate.now()))
				flag=true;
			else
				flag=false;
		else
			flag=false;
			
		return flag;
	}
	public Customer findCustomerId(int customerId)
	{
		List<Customer> customers=customerDao.getAllCustomers();
		System.out.println(customers);
		Customer cust=null;
		for(Customer customer:customers)
		{
			if(customerId==customer.getCustomerId())
			{	cust=customer;
				System.out.println("Customer returned ="+cust);
				break;
			}
		}
		System.out.println("Customer returned ="+cust);
		return cust;
		
		
		
	}

	@Override
	public void createAccount(Account account) {

		customerDao.createAccount(account);
		
	}

	@Override
	public Set<Account> getAllAccounts(Customer customer) {
		
		
		return customerDao.getAllAccounts(customer);
	}
	

	
}
