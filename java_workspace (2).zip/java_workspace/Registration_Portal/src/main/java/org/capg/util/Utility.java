package org.capg.util;

public class Utility {

	public static boolean isValidFirstName(String name)
	{
		return name.matches("[a-zA-Z]{3,}");
	}

	public static boolean isValidMobileNumber(String mobile) {
		
		return mobile.matches("[1-9][0-9]{9}");
		
	}

}
