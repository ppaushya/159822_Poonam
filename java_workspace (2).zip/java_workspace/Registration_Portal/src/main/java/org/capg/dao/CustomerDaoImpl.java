package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
//import org.capg.jdbc.CustomerDaoImpl;
import org.capg.model.Customer;
import org.apache.log4j.Logger;

public class CustomerDaoImpl implements ICustomerDao{
	//log file in src/main/resource folder
	public final static Logger logger= Logger.getLogger(CustomerDaoImpl.class);
	Scanner scan= new Scanner(System.in);

	@Override
	public void createCustomer(Customer customer) {
		
String str="insert into customer values(?,?,?,?,?,?)";
		
		try(Connection conn=getDbConnection()){
		
			java.sql.PreparedStatement statement=conn.prepareStatement(str);
			statement.setInt(1, customer.getRegistrationId());
			statement.setString(2, customer.getCustomerName());
			statement.setString(3, customer.getMobileNo());
			statement.setDouble(4, customer.getRegistrationFees());
			statement.setDouble(5, customer.getAge());
			statement.setDouble(6, customer.getActualRegFeesPaid());
			
			
			int count=statement.executeUpdate();
			
			if(count>0)
			{
				String select= "select MAX(RegistrationId) from customer";
				PreparedStatement pst1=conn.prepareStatement(select);
				ResultSet result=pst1.executeQuery();
				while(result.next())
				{
					System.out.println("RegistrationId is: "+result.getInt(1)+" \nCONGRATS "+
							customer.getCustomerName()+"!!\n Registration successful.\nRegistration fees is: "+
							customer.getActualRegFeesPaid());
				}
			}
	
		}
		catch(SQLException e)
		{
			logger.error("Sorry! Something went wrong!");
			e.printStackTrace();
		}
		
	}
//building connection
	private Connection getDbConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
			
		} catch (ClassNotFoundException|SQLException e) {
			logger.error("Sorry! Something went wrong!");
			e.printStackTrace();
		}
		return null;
	}
}
