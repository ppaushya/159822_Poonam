package org.capg.view;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.capg.dao.CustomerDaoImpl;
import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.util.Utility;


public class UserInteraction {

	public final static Logger logger= Logger.getLogger(CustomerDaoImpl.class);
	
	Scanner scan =new Scanner (System.in);
	public Customer getCustomerDetails()
	{
		ICustomerService customerService= new CustomerServiceImpl();
		Customer customer = new Customer();
		
		String name= promptName();
		customer.setCustomerName(name);
		
		customer.setMobileNo(promptMobileNo());
		
		double fees=1000;
		customer.setRegistrationFees(fees);
		
		
		
		try {
			int age=promptAge();
			customer.setAge(age);
			
			if(age<=0)
			{
				throw new InvalidAgeException("SORRY!! PLEASE ENTER A VALID AGE");
			}
			double actualFees=customerService.promptActualFees(age,fees);
			customer.setActualRegFeesPaid(actualFees);
				
		} catch (InvalidAgeException e) {
			logger.error("Sorry! Something went wrong!");
			e.printStackTrace();
		}		
		return customer;
		
	}

	

	private int promptAge() {
		
		int age;
		System.out.println("Enter age ");
		age=scan.nextInt();
		
		return age;
	}

	private String promptMobileNo() {
		
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter 10 digit mobile number");
			mobile=scan.next();
			flag=Utility.isValidMobileNumber(mobile);
			if(!flag)
				System.out.println("Enter a valid mobile number");
	
		}while(!flag);
		
		return mobile;
		
	}

	private String promptName() {
		
		boolean flag=false;
		String name;
		do {
			System.out.println("Enter first name");
			 name=scan.next();
			flag=Utility.isValidFirstName(name);
			if(!flag)
				System.out.println("Enter a valid first name");
	
		}while(!flag);
		
		return name;
		
	
	}
}
