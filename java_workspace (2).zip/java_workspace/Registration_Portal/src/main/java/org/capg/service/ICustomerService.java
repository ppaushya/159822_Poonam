package org.capg.service;

import org.capg.model.Customer;
import org.capg.view.InvalidAgeException;

public interface ICustomerService {

	public void createCustomer(Customer customer);

	public double promptActualFees(int age, double fees) throws InvalidAgeException;
}
