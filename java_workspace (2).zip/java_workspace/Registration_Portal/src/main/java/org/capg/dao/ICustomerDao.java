package org.capg.dao;

import org.capg.model.Customer;

public interface ICustomerDao {

	public void createCustomer(Customer customer);
}
