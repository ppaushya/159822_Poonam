package org.capg.service;

import org.capg.dao.CustomerDaoImpl;
import org.capg.dao.ICustomerDao;
import org.capg.model.Customer;
import org.capg.view.InvalidAgeException;

public class CustomerServiceImpl implements ICustomerService {

	ICustomerDao customerDao= new CustomerDaoImpl();
	@Override
	public void createCustomer(Customer customer) {
		
		customerDao.createCustomer(customer);
		
	}
	@Override
	public double promptActualFees(int age, double fees) throws InvalidAgeException {
		
			double commission;
			double actualFees = 0;
			try {
				if(age<=0)
					throw new InvalidAgeException("sorry invalid age");
				else if (age > 0 && age < 18) {
					commission = 0;
					actualFees = fees + fees * commission;
				} else if (age >= 18 && age < 25) {
					commission = 0.1;
					actualFees = fees + fees * commission;
				} else if (age >= 25 && age < 50) {
					commission = 0.2;
					actualFees = fees + fees * commission;
				} else if (age >= 50) {
					commission = 0.3;
					actualFees = fees + fees * commission;
				} 
			} catch (Exception  e) {
				e.printStackTrace();
			}
			
			return actualFees;
		}
	

}
