package org.capg.view;

public class InvalidAgeException extends Exception {

	public InvalidAgeException(String errorMessage)
	{
		super(errorMessage);
	}
}
