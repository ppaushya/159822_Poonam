package org.capg.boot;

import java.util.Scanner;

import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.view.UserInteraction;

public class BootClass {

	static Scanner scan= new Scanner(System.in);
	
	public static void main(String[] args) {
		
		ICustomerService customerService= new CustomerServiceImpl();
		UserInteraction userInteraction= new UserInteraction();
		
		System.out.println("1.Customer Registration\n2.Exit");
		System.out.println("Choose any of the above options[1,2]");
		int option =scan.nextInt();
		switch(option)
		{
		case 1:
			Customer customer=userInteraction.getCustomerDetails();
			customerService.createCustomer(customer);
			
			break;
			
		case 2:
			System.exit(0);
			
			break;
			
		default:
			System.out.println("Invalid choice!!");
			System.exit(0);
			
		}
	}

}
