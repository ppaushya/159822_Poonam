package org.capg.test;

//import static org.junit.Assert.*;

import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;
import org.capg.view.InvalidAgeException;
//import org.capg.view.UserInteraction;
import org.junit.Test;

public class TestCaseImpl {

	@Test(expected=NullPointerException.class)
	public void test_null_customer()  {
		
		Customer customer=null;
		ICustomerService customerService= new CustomerServiceImpl();
		customerService.createCustomer(customer);
	}

	
	
}
