
public class RegularClassDemo {

	int num;
	String name;
	
	class InnerClass{
		
			String adddress;
			public void show()
			{
				System.out.println("show");
			}
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
