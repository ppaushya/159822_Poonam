
public class Demo {

	public static void main(String[] args) {
		
		StringBuilder buffer= new StringBuilder(50);
		buffer.append("jerry hello hi");

		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());

		/*buffer.append("jerry hello hi");
		System.out.println(buffer);
		System.out.println(buffer.length());
		System.out.println(buffer.capacity());
*/

	}

}
