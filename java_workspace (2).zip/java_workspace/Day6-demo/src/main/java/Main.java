
public class Main {
	

	
	public static void main(String[] args) {
		

		Integer num=100;
		
		Integer integer= new Integer(100);
		Integer value= 100;
		Integer mynum= new Integer(100);
		

		System.out.println(value==(mynum));
		System.out.println(value.equals(mynum));

	}

}
