
import java.time.Instant;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DemoCalender {

	public static void main(String[] args) {


		
		LocalDate date= LocalDate.now();
		System.out.println(date);
		
		Instant instant=Instant.now();
		System.out.println(instant);
		Date newDate= Date.from(instant);
		System.out.println(newDate);
		
		Instant i=newDate.toInstant();
		System.out.println(i);




		

	}

}
