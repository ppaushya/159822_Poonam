import java.util.Date;
public class DateDemo {
	
	

	public static void main(String[] args) {

		Date today= new Date();
		System.out.println(today);
		
		@SuppressWarnings("deprecation")
		Date dob= new Date(1991-1900,01-1,23);
		System.out.println(dob);
		
		System.out.println(dob.getTime());
		System.out.println(dob.getDate());

		System.out.println(dob.getMonth());

		System.out.println(today.getYear());
		
		System.out.println(dob.getHours());


		System.out.println(dob.getMinutes());

		System.out.println(dob.getSeconds());

		today.setDate(11);

		System.out.println(today);

		
		


	}

}
