
public class MainClass {

	public static void main(String[] args) {
		 RegularClassDemo.InnerClass obj= new RegularClassDemo().new InnerClass();
		 obj.show();

	}

}
