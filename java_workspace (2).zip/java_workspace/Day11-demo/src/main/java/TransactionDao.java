
public interface TransactionDao {

	public void perfornTransaction();
}
