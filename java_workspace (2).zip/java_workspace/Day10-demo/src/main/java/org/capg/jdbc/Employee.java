package org.capg.jdbc;

import java.time.LocalDate;

public class Employee {

	private int empid;
	private String firstName,lastName;
	private double salary;
	private LocalDate dateOfJoining;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfBirth) {
		this.dateOfJoining = dateOfBirth;
	}
	public Employee(int empid, String firstName, String lastName, double salary, LocalDate dateOfSalary) {
		super();
		this.empid = empid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dateOfJoining = dateOfJoining;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", dateOfJoining=" + dateOfJoining + "]";
	}
	public Employee() {
		
		
	}
	
	
	
	
}
