package org.capg.jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {

	Scanner scan=new Scanner(System.in);
	
	public Employee createEmployee() {
		
		
		
		Employee employee=new Employee();
		System.out.println("Enter Employee Id:");
		employee.setEmpid(scan.nextInt());
		
		System.out.println("Enter Employee FirstName:");
		employee.setFirstName(scan.next());
		
		System.out.println("Enter Employee LastName:");
		employee.setLastName(scan.next());
		
		System.out.println("Enter Employee Salary:");
		employee.setSalary(scan.nextDouble());
		
		System.out.println("Enter Employee DateOf Joining[yyyy-mm-dd]:");
		String[] date=scan.next().split("-");
		employee.setDateOfJoining(LocalDate.of(
				Integer.parseInt(date[0]), 
				Integer.parseInt(date[1]), 
				Integer.parseInt((date[2]))));
		
		return employee;
	}

	public int promptEmployeeID() {
		
		
		int empId;
		
		System.out.println("Enter Employee Id:");
		empId=scan.nextInt();
		
		return empId;
	}



	public void printAllEmployees(List<Employee> employees) {
		
		System.out.println("EmployeeId\tFirstName\tLastName\tSalary\t\tDateOfjoining");
		for(Employee employee:employees)
			System.out.println(employee.getEmpid() +"\t\t"
					+employee.getFirstName()+"\t\t" 
					+employee.getLastName()+"\t\t" 
					+employee.getSalary()+"\t" 
					+employee.getDateOfJoining() );
		
	}


}
