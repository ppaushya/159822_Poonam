package org.capg.jdbc;

import java.util.List;

public interface EmployeeDao {

	
	public void createEmployee(Employee employee);

	public void deleteEmployee(int empId);

	public List<Employee> getAllEmployees();

	public void updateEmployee(int empId);
}
