package org.capg;

public class Main {

	public static void main(String[] args) {

		Sender <String> str= new Sender<>();
		str.setMessage("43563");
		System.out.println(str.getMessage());
		
		Sender <Integer> str1= new Sender<>();
		str1.setMessage1(345678);
		System.out.println(str1.getMessage());
		
		

	}

}
