package org.capg.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mysql.jdbc.PreparedStatement;

public class EmployeeDaoImpl implements EmployeeDao {

	Scanner scan= new Scanner(System.in);
	
	@Override
	public void createEmployee(Employee employee) {
		
		String str="insert into employee values(?,?,?,?,?)";
		
		try(Connection conn=getDbConnection()){
		
		java.sql.PreparedStatement statement=conn.prepareStatement(str);
		statement.setInt(1, employee.getEmpid());
		statement.setString(2, employee.getFirstName());
		statement.setString(3, employee.getLastName());
		statement.setDouble(4, employee.getSalary());
		statement.setDate(5,java.sql.Date.valueOf(employee.getDateOfJoining()));
		
		
		int count=statement.executeUpdate();
		
		if(count>0)
			System.out.println("Insertion done!");
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}

	private Connection getDbConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
			
		} catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deleteEmployee(int empId) {
		
		String sql="delete from employee where empid=?";
		try(Connection conn=getDbConnection()) {
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, empId);
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Deletion Done!");
			else
				System.out.println("Deletion Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		List<Employee> employees=new ArrayList<>();
		
		String sql="select * from employee";
		try(Connection conn=getDbConnection()) {
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				Employee employee=new Employee();
				employee.setEmpid(resultSet.getInt(1));
				employee.setFirstName(resultSet.getString("firstName"));
				employee.setLastName(resultSet.getString("lastName"));
				employee.setSalary(resultSet.getDouble("salary"));
				employee.setDateOfJoining(resultSet.getDate(5).toLocalDate());
				employees.add(employee);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		return employees;
	}

	@Override
	public void updateEmployee(int empId1) {
		
		char choice;
		int option;
		
		do {
			System.out.println("Enter the field to be updated:\n1.Employee First Name\n"
					+ "2.Employee Last Name\n3.Employee Salary");
			option=scan.nextInt();
			switch(option) {
			case 1:
				
					String sql="update employee set firstName=? where empid=? ";
					try(Connection conn=getDbConnection()){
						
						java.sql.PreparedStatement pst= conn.prepareStatement(sql);
						pst.setInt(2, empId1);
						pst.setString(1, "hello");
						
						int count=pst.executeUpdate();
						if(count>0)
							System.out.println("Updation Done!");
						else
							System.out.println("Updation Error!");
						
					}catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
				
				break;
			case 2:
				
					String sql1="update employee set lastName=? where empid=? ";
					try(Connection conn=getDbConnection()){
						
						java.sql.PreparedStatement pst= conn.prepareStatement(sql1);
						pst.setInt(2, empId1);
						pst.setString(1, "singh");
						
						int count=pst.executeUpdate();
						if(count>0)
							System.out.println("Updation Done!");
						else
							System.out.println("Updation Error!");
						
					}catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
					
				break;
			case 3:
				
					String sql2="update employee set salary=? where empid=? ";
					try(Connection conn=getDbConnection()){
						
						java.sql.PreparedStatement pst= conn.prepareStatement(sql2);
						pst.setInt(2, empId1);
						pst.setDouble(1, 200);
						
						int count=pst.executeUpdate();
						if(count>0)
							System.out.println("Updation Done!");
						else
							System.out.println("Updation Error!");
						
					}catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
				
				break;
			
			default:
				System.out.println("Invalid option!!");
				System.exit(0);
			}

			choice=scan.next().charAt(0);
		}while(choice=='y'|| choice=='Y');
		
		
	}

}
