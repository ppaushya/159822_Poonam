
public class ClassExcept {

	public static void main(String[] args) {
		
		Integer num1=100;
		Integer num2=null;
		Integer ans=null;
		try {
			 ans=num1+num2;
			System.out.println("answer "+ans);
			
			try {
			String num="00";
			int result=ans/7;
			System.out.println("result "+result);
			}catch(NumberFormatException e) {
				e.printStackTrace();

			}

			
		}catch(ArithmeticException|NullPointerException e) {
			e.printStackTrace();
	
		}
		
		//System.out.println("answer "+ans);

	}
	

}
