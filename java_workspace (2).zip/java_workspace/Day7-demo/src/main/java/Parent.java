import java.io.FileNotFoundException;

public class Parent {
	
	public void print() throws  FileNotFoundException ,InterruptedException{
		System.out.println("Hello parent");
	}
	public static void main(String[] args) { 
        
		
    } 

}
