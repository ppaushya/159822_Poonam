import java.io.FileNotFoundException;

public class Child extends Parent {

	
	@Override
	public void print() throws  FileNotFoundException ,InterruptedException
	{
		System.out.println("Hello parent");
	}
}
