
public class MainClass1 {

	public static void main(String[] args) {


		Child child= new Child();
	
		
		Parent p= new Child();
		p.show();

	}

}
