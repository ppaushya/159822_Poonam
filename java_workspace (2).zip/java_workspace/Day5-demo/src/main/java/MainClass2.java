
public class MainClass2 {

	public static void main(String[] args) {

		OrdinaryCall o= new OrdinaryCall();
		o.calculateCharges();
		
		LighteningCall l= new LighteningCall();
		l.calculateCharges();
		
		UrgentCall u= new UrgentCall();
		u.calculateCharges();
		
		
	}

}
