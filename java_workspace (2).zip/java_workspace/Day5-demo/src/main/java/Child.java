
public class Child extends Parent {
	int num=1000;

	char c='h';
	public void show()
	{
		System.out.println(c);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
