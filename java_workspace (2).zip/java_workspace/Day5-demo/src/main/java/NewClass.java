
public class NewClass {

	public static void main(String[] args) {
		
		Circle circle= new Circle(3);
		

		float area= circle.calculateArea();
		System.out.println("AREA IS: "+area);
		circle.draw();

	}

}
