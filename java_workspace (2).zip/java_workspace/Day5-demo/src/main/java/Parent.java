
public class Parent extends GrandParent{
	
	int num= 2000;
	
	public void show ()
	{
		System.out.println("parent class"+super.num);

	}

	public static void main(String[] args) {


	}

}
