
public abstract class Shape {
	
	
	int width;
	int height;
	
	public Shape()
	{
		System.out.println("Shape class no arg constructor");

		
	}
	public Shape(int width, int height)
	{
		this.width=width;
		this.height=height;
		System.out.println("Shape class full arg constructor"+ width+height);

	}
	
	public void info()
	{
		System.out.println("Shape information");
	}
	
	public abstract void draw();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
