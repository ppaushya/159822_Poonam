
public class OrdinaryCall extends Call {
	
	public void calculateCharges()
	{
		System.out.println("Charges are Ordinary");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
