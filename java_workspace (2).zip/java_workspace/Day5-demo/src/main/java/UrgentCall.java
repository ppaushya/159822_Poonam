
public class UrgentCall extends Call {
	
	
	
	public void calculateCharges()
	{
		System.out.println("Charges are urgent");
	}


}
