
public class Student {
	private int studId;
	private String firstName;
	private String lastName;
	private double rfees;
	
	//default constructor
	public Student()
	{
		studId=0;
		firstName="tom";
		lastName="singh";
		rfees=100;
		
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getRfees() {
		return rfees;
	}

	public void setRfees(double rfees) {
		this.rfees = rfees;
	}

	public static void main(String[] args) {
		

	}

}
