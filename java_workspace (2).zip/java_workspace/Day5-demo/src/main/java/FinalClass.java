
public class FinalClass {

	public static void main(String[] args) {


		Employee e= new Employee();
		e.getPerson();
		e.getEmployee();
		
		e.showEmployee();
		Employee e1= new Employee();


	}

}
