
public class GrandParent {

	int num= 3000;
	
	public void show ()
	{
		System.out.println("grand parent class"+num);

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
