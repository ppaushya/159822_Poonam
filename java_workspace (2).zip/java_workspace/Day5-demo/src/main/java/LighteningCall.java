
public class LighteningCall extends Call {
	
	public void calculateCharges()
	{
		System.out.println("Charges are Lightening");
	}


}
