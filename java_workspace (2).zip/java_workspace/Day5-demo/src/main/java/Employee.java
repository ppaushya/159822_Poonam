import java.util.Scanner;

public class Employee extends Person{
	
	double salary;
	boolean isPermanent;
	
	public void getEmployee()
	{
		Scanner s= new Scanner(System.in);
		System.out.println("Enter salary");
		salary=s.nextDouble();
		
		System.out.println("Enter isPermanent [true/false]");
		isPermanent=s.nextBoolean();
		//s.close();
	}
	
	public Employee()
	{
		super();
	}
	 public Employee(int personId, String firstName, String lastName, double salary, boolean isPermanent) {
		super(personId, firstName, lastName);
		this.salary = salary;
		this.isPermanent = isPermanent;
	}

	public void show()
	 {
		 System.out.println("employee class--> show method ");
	 }

	public void showEmployee()
	{
		showPerson();
		System.out.println(salary+" "+isPermanent);
	}

}
