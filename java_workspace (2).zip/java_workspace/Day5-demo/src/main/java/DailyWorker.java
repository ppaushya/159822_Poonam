
public class DailyWorker extends Worker{
	
	public DailyWorker()
	{
		
	}
	
	
	public DailyWorker(String name, float rate)
	{
		this.name=name;
		this.rate=rate;
	}
	
	public void ComPay(int hours)
	{
		salary=hours*rate;
		System.out.println("salary of "+name+" is "+salary );
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
