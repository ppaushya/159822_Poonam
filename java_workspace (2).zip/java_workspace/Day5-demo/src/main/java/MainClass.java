
public class MainClass {

	public static void main(String[] args) {
		Student s= new Student();
				
				s.setStudId(1001);
				s.setFirstName("ram");
				s.setLastName("hari");
				s.setRfees(10000);

				System.out.println(s.getStudId()+" "+ s.getFirstName()+" "+ s.getLastName()+" "+s.getRfees());

	}

}
