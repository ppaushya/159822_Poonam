
public class Circle extends Shape {
	
	final float pi=3.14f;
	float radius;

	public Circle()
	{
		System.out.println("Circle class no arg constructor");

	}
	
	public Circle(float radius)
	{
		//super(11,23);
		this.radius=radius;
		System.out.println("Circle class full arg constructor");

	}
	
	public float calculateArea()
	{
		return pi*radius*radius;
	}
	
	@Override
	public void draw()
	{
		System.out.println("Circle class draw method");

	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
