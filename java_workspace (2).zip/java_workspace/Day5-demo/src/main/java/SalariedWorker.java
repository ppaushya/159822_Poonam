
public class SalariedWorker extends Worker{
	
	public SalariedWorker()
	{
		
	}
	
	
	public SalariedWorker(String name, float rate)
	{
		this.name=name;
		this.rate=rate;
	}
	
	public void ComPay(int hours)
	{
		hours=40;
		salary=40*rate;
		System.out.println("salary of "+name+" is "+salary );
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
