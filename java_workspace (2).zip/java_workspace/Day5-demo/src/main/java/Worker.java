
public abstract class Worker {
	
	String name;
	float rate;
	float salary;
	
	public abstract void ComPay(int hours);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
