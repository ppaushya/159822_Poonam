
public abstract class Call {
	
	float duration;
	
	
	public abstract void calculateCharges();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
