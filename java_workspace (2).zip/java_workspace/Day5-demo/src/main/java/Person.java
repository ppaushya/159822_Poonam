import java.util.Scanner;

public class Person {

	int personId;
	 String firstName;
	 String lastName;
	 
	 public void getPerson()
	 {
		 Scanner s= new Scanner(System.in);
		 System.out.println("Enter person id");
		 personId=s.nextInt();
		 System.out.println("Enter first name");
		 firstName=s.next();
		 System.out.println("Enter last name");
		 lastName=s.next();
		 //s.close();
		 
	 }
	 public Person()
	 {
		 
	 }
	 

	 public Person(int personId, String firstName, String lastName) {
		super();
		this.personId = personId;
		this.firstName = firstName;
		this.lastName = lastName;
	}




	public void showPerson()
	 {
		 System.out.println(personId+" "+firstName+" "+lastName);
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
