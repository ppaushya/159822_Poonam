
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Worker d= new DailyWorker("tom", 100);
		d.ComPay(30);
		Worker s= new SalariedWorker("ram",200);
		s.ComPay(40);
		
	}

}
