package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {
	
	static final Logger logger=Logger.getLogger(Client.class);

	static Scanner scan=new Scanner (System.in);
	
	
	//getting details from customer
	public static DemandDraft get_customer_details() throws InvalidAmountException
	{
		DemandDraft demandDraft=new DemandDraft();
		
		System.out.print("Enter the name of the cutomer:");
		demandDraft.setCustomer_name(promptCustomerName());
		
		System.out.print("Enter customer phone number:");
		demandDraft.setPhone_number(promptPhoneNumber());
		
		System.out.print("In favor of:");
		demandDraft.setIn_favor_of(promptInFavorOf());
		
		System.out.println("Enter Demand Draft amount(in Rs):");
		double amount=promptAmount();
		demandDraft.setDd_amount(amount);
		
		System.out.println("Enter Remarks:");
		demandDraft.setDd_description(scan.next());
		
		demandDraft.setDd_commission(dd_commision_calculation(amount) );
		
		demandDraft.setDate_of_transaction(LocalDate.now());
		
		
		return demandDraft;
		
	}
	
	
	
	private static double promptAmount() throws InvalidAmountException {
		
		double amount= scan.nextDouble();
		if(amount<=0)
			throw new InvalidAmountException("Sorry!! Invalid Amount!!");
		
		return amount;
	}



	public static int dd_commision_calculation(double amount) 
	{
		int dd_commision = 0;
		if(amount<=5000)
		{
			dd_commision=10;
			
		}
		else if(amount>5001&& amount<=10000)
		{
			dd_commision=41;
			
		}
		else if(amount>10001&& amount<=100000)
		{
			dd_commision=51;
			
		}
		else if(amount>100001&& amount<=500000)
		{
			dd_commision=306;
			
		}

		return dd_commision;
		
	}
	
	
	
	private static String promptInFavorOf() {
		
		boolean flag=false;
		String in_favor;
		do {
			
			in_favor=scan.next();
			flag=in_favor.matches("[a-zA-Z]{3,}");
			if(!flag)
				System.out.println("Enter a valid in favor of name");
	
		}while(!flag);
		
		return in_favor;
	}



	private static String promptPhoneNumber() {
		
		boolean flag=false;
		String mobile;
		do {
			
			mobile=scan.next();
			flag=mobile.matches("[7-9][0-9]{9}");
			if(!flag)
				System.out.println("Enter a valid phone number");
	
		}while(!flag);
		
		return mobile;
	}



	private static String promptCustomerName() {
		
		boolean flag=false;
		String name;
		do {
			
			 name=scan.next();
			flag=name.matches("[a-zA-Z]{3,}");
			if(!flag)
				System.out.println("Enter a valid customer name");
	
		}while(!flag);
		
		return name;
		
	}



	public static void main(String[] args) {
		
		IDemandDraftService demandDraftService= new DemandDraftService();
		
		System.out.println("1) Enter Demand Draft Details");
		System.out.println("2) Exit");
		int choice=scan.nextInt();
		
		switch (choice)
		{
		case 1:
			DemandDraft demandDraft= new DemandDraft();
			try {
				demandDraft=get_customer_details();
			} catch (InvalidAmountException e) {
				logger.error("Connection Error",e);
				e.printStackTrace();
			}
			int id= demandDraftService.addDemandDraftDetails(demandDraft);
			demandDraft=demandDraftService.getDemandDraftDetails(id);
			
			
			break;
		case 2:
			System.exit(0);
			break;
		default:
			System.out.println("Please enter a valid choice!!");
		}
		
		

	}
}
