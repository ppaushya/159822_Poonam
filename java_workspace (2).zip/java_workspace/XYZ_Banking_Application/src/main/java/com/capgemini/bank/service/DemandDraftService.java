package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;

public class DemandDraftService implements IDemandDraftService{

	DemandDraftDAO demandDraftDao= new DemandDraftDAO();
	
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		
		int transactionId=demandDraftDao.addDemandDraftDetails(demandDraft);
		
		return transactionId;
	}

	
	
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		
		return demandDraftDao.getDemandDraftDetails(transactionId);
	}

}
