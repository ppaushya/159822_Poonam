package com.capgemini.bank.ui;

public class InvalidAmountException extends Exception {


	public InvalidAmountException(String errorMessage)
	{
		super(errorMessage);
	}
}
