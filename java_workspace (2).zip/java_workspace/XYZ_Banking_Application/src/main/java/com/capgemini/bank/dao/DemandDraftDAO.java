package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {

	static final Logger logger=Logger.getLogger(DemandDraftDAO.class);
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		String sql="insert into demand_draft(customer_name,in_favor_Of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description)"
				  +"values (?,?,?,?,?,?,?)";
		
		int transactionId = 0;
		try(Connection conn=getDbConnection())
		{
			
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, demandDraft.getCustomer_name());
			pst.setString(2, demandDraft.getIn_favor_of());
			pst.setString(3, demandDraft.getPhone_number());
			
			Date date = Date.valueOf(demandDraft.getDate_of_transaction());
            pst.setDate(4, date);
			pst.setDouble(5, demandDraft.getDd_amount());
			pst.setInt(6, demandDraft.getDd_commission());
			pst.setString(7, demandDraft.getDd_description());
			
			 int count=pst.executeUpdate();
				
			 if(count>0)
			 {
				 String str="select max(transaction_Id) from demand_draft";
				 java.sql.PreparedStatement pst1=conn.prepareStatement(str);
				 ResultSet set=pst1.executeQuery();
				 while(set.next())
					  transactionId = set.getInt(1);			 
				 logger.error("Insertion Successful");
			 }
		
		
		}catch (Exception e) {
		
			logger.error("Connection Error",e);
		
		} 
		return transactionId;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {

		DemandDraft demandDraft = null;
		try(Connection conn=getDbConnection())
		{
			String str="select max(transaction_Id) from demand_draft";
			 java.sql.PreparedStatement pst2=conn.prepareStatement(str);
			 ResultSet result=pst2.executeQuery();
			 if(result.next())
			 {
				 demandDraft.setTransaction_id(result.getInt(1));
				 demandDraft.setCustomer_name(result.getString(2));
				 demandDraft.setIn_favor_of(result.getString(3));
				 demandDraft.setPhone_number(result.getString(4));
				 Date date=result.getDate(5);
				 demandDraft.setDate_of_transaction(null);
				 demandDraft.setDd_amount(result.getDouble(6));
				 demandDraft.setDd_commission(result.getInt(7));
				 demandDraft.setDd_description(result.getString(8));
			 }
			 			 
			 logger.error("Retrieval Successful");
		} catch (SQLException e) {
			logger.error("Connection Error",e);
			
		}
		
		System.out.println("Your Demand Draft request have been successfully registered"
	       		 +"along with "+ transactionId);
		return demandDraft;
	}
	
	

	private Connection getDbConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
			
		} catch (ClassNotFoundException|SQLException e) {
			logger.error("Sorry! Something went wrong!");
			e.printStackTrace();
		}
		return null;
	}
}
