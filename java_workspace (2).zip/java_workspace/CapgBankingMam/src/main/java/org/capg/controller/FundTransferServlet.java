package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/FundTransferServlet")
public class FundTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out= response.getWriter();
		HttpSession session= request.getSession();
		
		ILoginService loginService= new LoginServiceImpl();
		
		List<Account> accounts=loginService.chooseAccount(Integer.parseInt(session.getAttribute("custId").toString()));
		List<Account> otherAccounts= loginService.otherAccount(Integer.parseInt(session.getAttribute("custId").toString()));
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>capgBanking</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method=\"post\" action=\"FundTransferServlet\">\r\n" + 
				"	<div>\r\n" + 
				"		<table>\r\n" + 
				"			<tr>\r\n" + 
				"				<th colspan=\"3\">Fund Transfer </th>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>From Account:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<select name=\"fromAccountNumber\">\r\n" ); // +account.getAccountNumber()+"-"+account.getAccountType()+
										for(Account account:accounts)
										{
										out.println("<option value=\""+account.getAccountNumber()+"\">"+account.getAccountNumber()+"-"+account.getAccountType()+"</option>\r\n"
										);} 
										out.println("</select>\r\n" +
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td>To Account:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<select name=\"toAccountNumber\">\r\n" ); // +account.getAccountNumber()+"-"+account.getAccountType()+
										for(Account account:otherAccounts)
										{
										out.println("<option value=\""+account.getAccountNumber()+"\">"+account.getAccountNumber()+"-"+account.getAccountType()+"</option>\r\n"
										);} 
										out.println("</select>\r\n" +
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Amount:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"amount\" size=\"20\">  \r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Description:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\" name=\"description\" size=\"20\">  \r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"submit\" value=\"Do Transaction\" name=\"fundTransfer\" >\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"		\r\n" + 
				"		</table>\r\n" + 
				"	\r\n" + 
				"	</div>\r\n" + 
				"\r\n" + 
				"</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Accessing values entered by user
		String fromAccountNumber=request.getParameter("fromAccountNumber");
		String toAccountNumber=request.getParameter("toAccountNumber");
		String amount=request.getParameter("amount");
		String description=request.getParameter("description");
		
		Account account1 = new Account();
		Account account2 = new Account();
		Transaction txn = new Transaction();
		//updating variables according to user entered values
		account1.setAccountNumber(Long.parseLong(fromAccountNumber));		
		txn.setFromAccount(account1);
		txn.setAccount(account1);
		account2.setAccountNumber(Long.parseLong(toAccountNumber));	
		txn.setToAccount(account2);
		txn.setTransactionType("Fund Transfer");
		txn.setAmount(Double.parseDouble(amount));
		txn.setDescription(description);
		txn.setTransactionDate(LocalDate.now());
		
		
		//Redirection
		ILoginService loginService= new LoginServiceImpl();
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		//System.out.println(custId);
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		txn.setCustomer(customer);
				
		boolean flag=loginService.depositWithdraw(txn);
		if(flag) {
			response.sendRedirect("FundTransferServlet");
			System.out.println("Transaction Done.....");
		}
		else
			System.out.println("Transaction Failed.....");
			
			


		
		
	}

}
