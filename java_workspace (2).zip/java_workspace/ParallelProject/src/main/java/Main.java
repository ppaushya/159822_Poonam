import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	Scanner scan= new Scanner(System.in);
	
	public void loadCustomers()
	{
		
		ArrayList<Customer> customer=new ArrayList<>();
		
		ArrayList<String> address= new ArrayList<>();
		
		
		//Getting and setting customer details
		for(int i=0; i<5; i++)
		{
			
			System.out.println("----------Enter the details of customers----------");
			
			System.out.println("Enter the customer id");
			int id=scan.nextInt();
			
			System.out.println("Enter the name");
			String fullname= scan.next();
			
			System.out.println("---Enter the address details---");
			System.out.println("Enter the Street name");
			String st= scan.next();
			System.out.println("Enter the address");
			String add= scan.next();

			System.out.println("Enter the city");
			String cit= scan.next();

			System.out.println("Enter the state");
			String stat= scan.next();


			System.out.println("Enter the mobile number");
			String mobile=scan.next();

			System.out.println("Enter the email id");
			String email = scan.next();
			
			//String str=new String(st,add,cit,stat);
			address.add(new Address(st,add,cit,stat));
			
			customer.add(new Customer(id,fullname,address,mobile,email)); 
	
			
		}
		for(Customer cust:customer)
		{
			System.out.println(cust+" , ");
		}
			
	}
	


	

	public static void main(String[] args) {
		
		Main obj=new Main();
		obj.loadCustomers();


	}

}