
public class AccountTransactions {
	
	public long generateAccountNo()
	{
		return (long)(Math.random()*10000)/1000;
	}

}
