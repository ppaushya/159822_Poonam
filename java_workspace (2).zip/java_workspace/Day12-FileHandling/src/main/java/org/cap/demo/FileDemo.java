package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		
		File file= new File("C:\\demo\\myDemo.txt");
		
		
		
		if(file.isFile()) {
			
			if(file.exists()) {
				System.out.println("Readable"+ file.canRead());
				System.out.println("Writable"+ file.canWrite());
				System.out.println("Executable"+ file.canExecute());
				System.out.println("path"+ file.getAbsolutePath());
			}
			else
				System.out.println("Sorry! File does not exist");
				
		}
		else if(file.isDirectory()) {
			String[] names=file.list();
			for (String name:names)
			{
				System.out.println(name);
			}
		}
		else
			System.out.println("Sorry! The file/directory does not exist.");
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		System.out.println("FreeSpace "+ file.getFreeSpace());
		System.out.println("TotalSpace "+ file.getTotalSpace());
		System.out.println("UsedSpace "+ file.getUsableSpace());
		

	}

}
