package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharacterDemo {

	public static void main(String[] args) {
		
	File file= new File("C:\\demo\\sample.txt");
	
	String greet="Good Afternoon";
	//int ch;
	try (FileWriter writer= new FileWriter (file)){
		/*char[] ch=greet.toCharArray();
		
		for(char c:ch)
			writer.write(c);*/
		
		writer.write(greet);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	}
	
	
}
