package org.cap.demo;

import java.io.*;
import java.util.Scanner;

public class EmployeeReadWrite {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		
		File file= new File("C:\\demo\\employee.txt");

		int employeeId;
		String employeeName;
		double salary;
		boolean isPermanent;
		char gender;
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter employee id");
			employeeId=scan.nextInt();
			
			System.out.println("Enter employee name");
			employeeName=scan.next();
			
			System.out.println("Enter employee salary");
			salary=scan.nextDouble();
			
			System.out.println("Enter is employee permament?[true/false]");
			isPermanent=scan.nextBoolean();
			
			System.out.println("Enter employee gender[M/F]");
			gender=scan.next().charAt(0);
		
		
			try(FileOutputStream out= new FileOutputStream(file);
					DataOutputStream outputStream= new DataOutputStream(out)) {
				outputStream.writeInt(employeeId);
				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException  e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	}

}
