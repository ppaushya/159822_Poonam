package org.cap.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReverseReadFile {

	

	public static void main(String[] args) {
		
		File file= new File("C:\\demo\\sample.txt");
		StringBuilder str=new StringBuilder();
		int ch;
		try (FileReader reader= new FileReader (file)){
			
			do{
			 ch=reader.read();
			 str.append((char)ch);
			 System.out.print((char)ch);
			}while(ch!=-1);
			
			str=str.reverse();
			//str=str.reverse();
			System.out.println(str);
			/*
			for(char character='\0';;character--)
			{
				ch=reader.read();
				System.out.println(character);
			}*/
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	
	
}
