package org.cap.demo;

import java.io.File;
import java.util.Scanner;

public class UserInteraction {

	
	public Product getProductDetails() {
		
		Scanner scan= new Scanner (System.in);
		
		
		
		Product product = new Product();
		System.out.println("Enter product ID");
		product.setProductId(scan.nextInt());
		
		System.out.println("Enter product name");
		product.setName(scan.next());
		
		System.out.println("Enter product quantity");
		product.setQuantity(scan.nextDouble());
		
		System.out.println("Enter product cost");
		product.setCost(scan.nextDouble());
		
		return product;
		
	}
}
