package org.cap.demo;

import java.io.Serializable;
import java.time.LocalDate;

public class Product implements Serializable {

	
	int productId;
	String name;
	double quantity;
	double cost;
	
	
	
	
	public Product() {
		
	}
	public Product(int productId, String name, double quantity, double cost) {
		super();
		this.productId = productId;
		this.name = name;
		this.quantity = quantity;
		this.cost = cost;
		
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", quantity=" + quantity + ", cost=" + cost
				+ "]";
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	

	
}
