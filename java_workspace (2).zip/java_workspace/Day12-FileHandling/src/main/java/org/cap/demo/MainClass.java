package org.cap.demo;

import java.io.File;

public class MainClass {

	public static void main(String[] args) {
		
		UserInteraction userInteraction = new UserInteraction();
		Product product;
		
		File file= new File("C:\\demo\\product.txt");
		
		for (int i=0;i<5;i++)
		{
			product=userInteraction.getProductDetails();
			
		}

	}

}
