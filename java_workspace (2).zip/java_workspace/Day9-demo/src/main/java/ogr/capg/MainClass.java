package ogr.capg;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;

public class MainClass {

	public static void main(String[] args) {
		/*HashSet<Employee> employee= new HashSet<>();
		
		employee.add(new Employee(3,"tom","jerry",256000,LocalDate.now()));
		employee.add(new Employee(32,"hi","jerry",4000,LocalDate.now()));
		employee.add(new Employee(365,"hello","jerry",456000,LocalDate.now()));
		employee.add(new Employee(5,"yo","jerry",235400,LocalDate.now()));
		employee.add(new Employee(57,"hmm","jerry",2456400,LocalDate.now()));
		employee.add(new Employee(345,"yumm","jerry",234600,LocalDate.of(2017,2,22)));
		employee.add(new Employee(345,"yumm","jerry",234600,LocalDate.of(2017,2,22)));
		Iterator<Employee> iterator= employee.iterator();
		
		while (iterator.hasNext())
		{
			Employee employee1 =  iterator.next();
			System.out.println(employee1);
		}*/
		
		/*LinkedHashSet<Employee> employee= new LinkedHashSet<>();
		
		employee.add(new Employee(3,"tom","jerry",256000,LocalDate.now()));
		employee.add(new Employee(32,"hi","jerry",4000,LocalDate.now()));
		employee.add(new Employee(365,"hello","jerry",456000,LocalDate.now()));
		employee.add(new Employee(5,"yo","jerry",235400,LocalDate.now()));
		employee.add(new Employee(57,"hmm","jerry",2456400,LocalDate.now()));
		employee.add(new Employee(345,"yumm","jerry",234600,LocalDate.of(2017,2,22)));
		employee.add(new Employee(345,"yumm","jerry",234600,LocalDate.of(2017,2,22)));
		Iterator<Employee> iterator= employee.iterator();
		
		while (iterator.hasNext())
		{
			Employee employee1 =  iterator.next();
			System.out.println(employee1);
		}
		
		
*/
		
/*TreeSet<Employee> employee= new TreeSet<>();
		
		employee.add(new Employee(3,"tom","jerry",256000,LocalDate.now()));
		employee.add(new Employee(32,"hi","jerry",4000,LocalDate.now()));
		employee.add(new Employee(365,"hello","jerry",456000,LocalDate.now()));
		employee.add(new Employee(5,"yo","jerry",235400,LocalDate.now()));
		employee.add(new Employee(57,"hmm","jerry",2456400,LocalDate.now()));
		employee.add(new Employee(345,"yumm","jerry",234600,LocalDate.of(2017,2,22)));
		employee.add(new Employee(345,"yuho","jerry",234600,LocalDate.of(2017,2,22)));
		Iterator<Employee> iterator= employee.iterator();
		
		while (iterator.hasNext())
		{
			Employee employee1 =  iterator.next();
			System.out.println(employee1);
		}*/

		List<Employee> employee= new ArrayList<>();
		
		employee.add(new Employee(3,"tom","jerry",256000,LocalDate.now()));
		employee.add(new Employee(32,"hi","jerry",4000,LocalDate.now()));
		employee.add(new Employee(365,"hello","jerry",456000,LocalDate.now()));
		employee.add(new Employee(5,"yo","jerry",235400,LocalDate.now()));
		employee.add(new Employee(57,"hmm","jerry",2456400,LocalDate.now()));
		employee.add(new Employee(345,"yumm","jerry",234600,LocalDate.of(2017,2,22)));
		employee.add(new Employee(345,"yuho","jerry",234600,LocalDate.of(2017,2,22)));
		
		//sorting of array list
		Collections.sort(employee);
		
		Iterator<Employee> iterator= employee.iterator();
		while (iterator.hasNext())
		{
			Employee employee1 =  iterator.next();
			System.out.println(employee1);
		}
		
		Collections.sort(employee, new SortByFirstName());
		
		System.out.println("------------------");
		Iterator<Employee> iterator1= employee.iterator();
		while (iterator1.hasNext())
		{
			Employee employee2 =  iterator1.next();
			System.out.println(employee2);
		}
		
	}

}
