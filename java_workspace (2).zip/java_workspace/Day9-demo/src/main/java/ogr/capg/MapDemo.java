package ogr.capg;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {


		Map<Integer, String> maps=new HashMap<>();
		
		maps.put(1, "one");
		maps.put(1, "Three");
		maps.put(3, "null");
		maps.put(34, "ThirtyFour");
		maps.put(7, "null");
		//maps.put(null, "Sixty Eight");
		//maps.put(null, " Eight");
		//maps.put(null, "Sixty ");
		
		//System.out.println(maps);
		
		/*Set<Integer> set=maps.keySet();
		
		Iterator<Integer> iterator=set.iterator();
		while(iterator.hasNext())
		{
			int key=iterator.next();
			System.out.println(key+"--> "+maps.get(key));
		}*/
		
		Collection<String> values=maps.values();
		
		for(String str:values)
			System.out.println(str);
	}

}
