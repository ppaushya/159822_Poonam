package ogr.capg;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		HashSet<Integer> set= new HashSet<>();
		
		set.add(24);
		set.add(44);
		set.add(null);
		set.add(45756);
		set.add(null);
		set.add(5473);
		set.add(457);
		set.add(null);
		set.add(24);
		
		for(Integer num:set)
		{
			System.out.println(num+" , ");
		}

		LinkedHashSet<Integer> set1= new LinkedHashSet<>();
		
		set1.add(24);
		set1.add(44);
		set1.add(null);
		set1.add(45756);
		set1.add(null);
		set1.add(5473);
		set1.add(457);
		set1.add(null);
		set1.add(24);
		
		for(Integer num:set1)
		{
			System.out.println(num+" , ");
		}
		
		TreeSet<Integer> set2= new TreeSet<>();
		
		set2.add(24);
		set2.add(44);
		//set2.add(null);
		set2.add(45756);
		//set2.add(null);
		set2.add(5473);
		set2.add(457);
		//set2.add(null);
		set2.add(24);
		
		for(Integer num:set2)
		{
			System.out.println(num+" , ");
		}
		

	}

}
