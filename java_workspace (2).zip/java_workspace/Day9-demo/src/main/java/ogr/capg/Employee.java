package ogr.capg;

import java.time.LocalDate;
//import java.util.HashSet;

public class Employee implements Comparable<Employee> {
	
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	private LocalDate dob;
	
	

	



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + employeeId;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}







	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (employeeId != other.employeeId)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
			return false;
		return true;
	}







	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", dob=" + dob + "]";
	}







	public Employee(int employeeId, String firstName, String lastName, double salary, LocalDate dob) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.dob = dob;
	}







	public static void main(String[] args) {
		
		

	}







	/*@Override
	public int compareTo(Employee emp) {


		if(this.getEmployeeId()>emp.getEmployeeId())
		{
			return 1;
		}
		else if(this.getEmployeeId()<emp.getEmployeeId())
		{
			return -1;
		}
		else 
			return 0;
	}*/
	
	@Override
	public int compareTo(Employee emp) {


		if(this.getFirstName().compareTo(emp.getFirstName())>0)
		{
			return 1;
		}
		else if(this.getFirstName().compareTo(emp.getFirstName())<0)
		{
			return -1;
		}
		else 
			return 0;
	}







	public String getFirstName() {
		return firstName;
	}







	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}







	public int getEmployeeId() {
		return employeeId;
	}







	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}








}
