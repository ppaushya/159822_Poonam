package ogr.capg;

public class Customer implements Comparable<Customer>{
	
	private int customerId;
	private String Name;
	
	
	public Customer(int customerId, String name) {
		super();
		this.customerId = customerId;
		Name = name;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", Name=" + Name + "]";
	}


	public Customer() {
		super();
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Name == null) ? 0 : Name.hashCode());
		result = prime * result + customerId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (Name == null) {
			if (other.Name != null)
				return false;
		} else if (!Name.equals(other.Name))
			return false;
		if (customerId != other.customerId)
			return false;
		return true;
	}
	
	
	


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	@Override
	public int compareTo(Customer cust) {
		
		if(this.getCustomerId()>cust.getCustomerId())
			return 1;
		else if(this.getCustomerId()<cust.getCustomerId())
			return -1;
		else
			return 0;
	}
	
	

}
