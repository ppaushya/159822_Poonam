package ogr.capg;

import java.util.Comparator;

public class SortByFirstName implements Comparator<Employee> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compare(Employee emp1, Employee emp2) {
		
		if(emp1.getEmployeeId()>emp2.getEmployeeId())
			return 1;
		else if(emp1.getEmployeeId()<emp2.getEmployeeId())
			return -1;
		else
			return 0;
	}

}
