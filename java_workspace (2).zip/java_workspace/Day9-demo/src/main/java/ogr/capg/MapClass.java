package ogr.capg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapClass {

	public static void main(String[] args) {
		
		Map<Customer,Address> map= new TreeMap();
		
		map.put(new Customer(1,"tom"), new Address("new","dashmesh","ldh","pun"));
		map.put(new Customer(2,"num"), new Address("dy","nagar","dt","d"));
		map.put(new Customer(5,"har"), new Address("tu","ludhiana","sdt","er"));
		map.put(new Customer(3,"tow"), new Address("tua","punjab","drt","puen"));
		map.put(new Customer(3,"tow"), new Address("df","dffh","fdhfdh","dfff"));

		
		System.out.println(map);
		
		Set<Customer> set=map.keySet();
		
		Iterator<Customer> iterator=set.iterator();
		while(iterator.hasNext())
		{
			Customer key=iterator.next();
			System.out.println(key+"--> "+map.get(key));
		}
		
	}

}
