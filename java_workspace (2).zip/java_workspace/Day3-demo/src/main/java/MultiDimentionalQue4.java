import java.util.Scanner;

public class MultiDimentionalQue4 {
	
	int[][] arr1,arr2,sum,product;
	int row1, col1,row2,col2;
	
	Scanner s=new Scanner (System.in);
	
	
	public int[][] getElements(int[][] arr, int row, int col)
	{
		arr= new int[row][col];
		System.out.println("Enter elements");

		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				arr[i][j]=s.nextInt();
			}
		}
		return arr;
	}
	
	public void printElements(int[][] arr,int row, int col)
	{
		System.out.println("Matrix is:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
	
	public void addElements(int[][] arr1, int[][] arr2)
	{
		sum=new int[row1][col1];
		for(int i=0;i<row1;i++)
		{
			for(int j=0;j<col1;j++)
			{
				sum[i][j]=arr1[i][j]+arr2[i][j];
			}
		}
	}
	
	public void productElements(int[][]arr1, int[][] arr2)
	{
		product=new int[row1][col1];
		for(int i=0;i<row1;i++)
		{
			for(int j=0;j<col1;j++)
			{
				product[i][j]=arr1[i][j]*arr2[j][i]+product[i][j];
			}
		}
	}

	public static void main(String[] args) {
		
		MultiDimentionalQue4 a= new MultiDimentionalQue4();
		
		System.out.println("Enter Row");
		a.row1=a.s.nextInt();
		System.out.println("Enter Col");
		a.col1=a.s.nextInt();
		if(a.row1==a.col1)
		{
			a.arr1=a.getElements(a.arr1,a.row1,a.col1);
			a.printElements(a.arr1,a.row1,a.col1);
			System.out.println("Enter Row");
			a.row2=a.s.nextInt();
			System.out.println("Enter Col");
			a.col2=a.s.nextInt();
			if(a.row2==a.col2)
			{
				a.arr2=a.getElements(a.arr2,a.row2,a.col2);
				a.printElements(a.arr2,a.row2,a.col2);
				if(a.row1==a.row2&&a.col1==a.col2)
				{
					a.addElements(a.arr1,a.arr2);
					a.printElements(a.sum, a.row1, a.col1);
					a.productElements(a.arr1,a.arr2);
					a.printElements(a.product, a.row1, a.col1);
				}
			}
			
		}
		
	}

}
