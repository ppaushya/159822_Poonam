import java.util.Scanner;

public class BiggestElement {
	
	int[] myArray;
	
	public void getArrayElements(int size)
	{	
		myArray= new int[size];
		Scanner scanner=new Scanner(System.in);
		System.out.println("ENTER "+size+"Array Elements");
		for(int i=0;i<size;i++)
			myArray[i]=scanner.nextInt();
		scanner.close();
		
	}
	
	public void printArrayElements()
	{
		for (int i=0;i<myArray.length;i++)
			System.out.println(myArray[i]);
	}
	
	public int bigElement(int size)
	{
		int temp=0;
		for(int i=0;i<size;i++)
		{
			if(temp<myArray[i])
			{	
				temp=myArray[i];
			}
		}
		return temp;

	}
	public int smallElement(int size)
	{
		int temp=1000000000;
		for(int i=0;i<size;i++)
		{
			if(temp>myArray[i])
			{	
				temp=myArray[i];
			}
		}
		return temp;

	}


	public static void main(String[] args) {
		
		BiggestElement obj=new BiggestElement();
		int temp=0;
		obj.getArrayElements(4);
		obj.printArrayElements();
		temp=obj.bigElement(4);
		System.out.println("Biggest Number:"+temp);
		temp=obj.smallElement(4);
		System.out.println("Smallest Number:"+temp);
		
	}

}
