import java.util.Scanner;

public class StrArray {

	String[] myStr;
	
	public void acceptString(int size)
	{
		Scanner scanner = new Scanner (System.in);
		myStr= new String[size];
		System.out.println("ENTER ELEMENTS OF ARRAY");
		for(int i=0;i<size;i++)
		{
			myStr[i]=scanner.nextLine();
		}
		scanner.close();
	}
	
	public void printString()
	{
		for(int i=0; i<myStr.length;i++)
		{
			System.out.println(myStr[i]);
		}
	}
	
	/*public void reverse()
	{
		for(int i=0;i<myStr.length;i++)
		{
			String temp=myStr[i];
			myStr[i]=myStr[myStr.length-1];
			myStr[myStr.length-1]=temp;
			
		}
	}*/
	
	public void reverse(int size)
	{
		if(size%2!=0)
		{
			for(int i=0;i<(size/2)-1;i++)
			{	
				String a= myStr[i];
				myStr[i]=myStr[size-i-1];
				myStr[size-i-1]=a;
			}
		}
		else
		{
			for(int i=0;i<size/2;i++)
			{	
				String a= myStr[i];
				myStr[i]=myStr[size-i-1];
				myStr[size-i-1]=a;
			}
		}
		
	}
	
	public void sort(int size)
	{
		for(int i=0;i<size;i++)
		{
			for(int j=i;j<size;j++)
			{
				if(myStr[i].compareTo(myStr[j])>0)
				{
					String a=myStr[i];
					myStr[i]=myStr[j];
					myStr[j]=a;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		
		StrArray s= new StrArray();
		s.acceptString(5);
		s.printString();
		s.reverse(5);
		s.printString();
		s.sort(5);
		s.printString();


	}

}
