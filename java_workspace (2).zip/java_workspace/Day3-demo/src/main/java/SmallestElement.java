import java.util.Scanner;

public class SmallestElement {

	int[] myArray;
	
	public void getArrayElements(int size)
	{	
		myArray= new int[size];
		Scanner scanner=new Scanner(System.in);
		System.out.println("ENTER "+size+"Array Elements");
		for(int i=0;i<size;i++)
			myArray[i]=scanner.nextInt();
		scanner.close();
	}
	
	
	public void printArrayElements()
	{
		for (int i=0;i<myArray.length;i++)
			System.out.println(myArray[i]);
	}
	
	public int findSmallestElement(int[] arr)
	{
		int temp=0;
		//sort
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i;j<arr.length-1;j++)
			{
				if(arr[i]>arr[j+1])
				{
					int a=arr[i];
					arr[i]=arr[j+1];
					arr[j+1]=a;
				}
			}
		}
		
		//check sequence
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i+1]!=arr[i]+1)
			{
				System.out.println("not in sequence");
				temp=arr[0]+1;
				return temp;
			}
			
		}
		System.out.println("in sequence");
		temp=arr[arr.length-1]+1;
		return temp;

	}
	
	
	public static void main(String[] args) {
		
		int a=0;
		SmallestElement s= new SmallestElement();
		s.getArrayElements(4);
		s.printArrayElements();
		a=s.findSmallestElement(s.myArray);
		System.out.println(a);
		
		
	}

}
