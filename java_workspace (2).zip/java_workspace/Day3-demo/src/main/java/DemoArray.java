import java.util.Scanner;

public class DemoArray {
	
	int[] myArray;
	
	
	public void getArrayElements(int size)
	{	
		myArray= new int[size];
		Scanner scanner=new Scanner(System.in);
		System.out.println("ENTER "+size+"Array Elements");
		for(int i=0;i<size;i++)
			myArray[i]=scanner.nextInt();
		scanner.close();
		
	}
	
	public void printArrayElements()
	{
		for (int i=0;i<myArray.length;i++)
			System.out.println(myArray[i]);
	}
	
	
	public void reverse(int size)
	{
		if(size%2!=0)
		{
			for(int i=0;i<(size/2)-1;i++)
			{	
				int a= myArray[i];
				myArray[i]=myArray[size-i-1];
				myArray[size-i-1]=a;
			}
		}
		else
		{
			for(int i=0;i<size/2;i++)
			{	
				int a= myArray[i];
				myArray[i]=myArray[size-i-1];
				myArray[size-i-1]=a;
			}
		}
		
	}
	
	public void sort(int size)
	{
		for(int i=0;i<size;i++)
		{
			for(int j=i;j<size-1;j++)
			{
				if(myArray[i]>myArray[j+1])
				{
					int a=myArray[i];
					myArray[i]=myArray[j+1];
					myArray[j+1]=a;
				}
			}
		}
	}
	
	public void biggestElement()
	{
		System.out.println("Biggest Element:"+myArray[0]);
	}
	
	public void smallestElement()
	{
		System.out.println("Smallest Element:"+myArray[myArray.length-1]);
	}

	public void evenNumbers()
	{
		int sum=0;
		for(int i=0;i<myArray.length;i++)
		{
			if(myArray[i]%2==0)
			{
				System.out.println(myArray[i]);
				sum=sum+myArray[i];
			}
		}
		System.out.println("Sum of even elements:" + sum);
		
	}

	public static void main(String[] args) {
		
		DemoArray obj=new DemoArray();
		
		obj.getArrayElements(10);
		obj.printArrayElements();
		obj.reverse(10);
		obj.printArrayElements();
		obj.sort(10);
		obj.printArrayElements();
		obj.biggestElement();
		obj.smallestElement();
		obj.evenNumbers();

	}

}
