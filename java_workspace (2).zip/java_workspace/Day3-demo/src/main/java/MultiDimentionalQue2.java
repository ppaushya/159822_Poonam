import java.util.Scanner;

public class MultiDimentionalQue2 {
	
	int[][] arr;
	int row,col,sum=0;
	
	Scanner s=new Scanner(System.in);
	
	public void getSize()
	{
		System.out.println("Enter Row");
		row=s.nextInt();
		System.out.println("Enter Col");
		col=s.nextInt();
	}
	
	public void getElements()
	{
		arr= new int[row][col];
		System.out.println("Enter elements");

		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				arr[i][j]=s.nextInt();
			}
		}
	}
	
	public void printElements()
	{
		System.out.println("Matrix is:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
		
		
	public void add()
	{
		int a=1000000000;
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				sum=sum+arr[i][j];
			}
			System.out.println(sum+"\t");
			
			if(a>sum)
			{
				a=sum;
			}
			sum=0;
		}
		System.out.println(a+"\t");
	}
	

	public static void main(String[] args) {
		
		MultiDimentionalQue2 m=new MultiDimentionalQue2();
		m.getSize();
		m.getElements();
		m.printElements();
		m.add();
		
		
	}

}
