import java.util.Scanner;

public class MultiDimension {
	
	

	public static void main(String[] args) {
		
		int[][] arr= new int[3][2];
		
		arr[0][0]=12;
		arr[0][1]=14;
		
		arr[1][0]=45;
		arr[1][1]=57;
		
		arr[2][0]=67;
		arr[2][1]=86;
		
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter elements");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				arr[i][j]=s.nextInt();
			}
		}
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
				
		s.close();
	}

}
