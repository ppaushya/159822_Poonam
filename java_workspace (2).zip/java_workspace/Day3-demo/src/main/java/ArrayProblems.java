import java.util.Scanner;

public class ArrayProblems {
	
	Scanner s= new Scanner(System.in);
	
	int[][] arr;
	int row,col;
	
	public void getSize()
	{
		System.out.println("Enter Row");
		row=s.nextInt();
		System.out.println("Enter Col");
		col=s.nextInt();
	}
	
	public void getElements()
	{
		arr= new int[row][col];
		System.out.println("Enter elements");

		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				arr[i][j]=s.nextInt();
			}
		}
	}
	
	public void printElements()
	{
		System.out.println("Matrix is:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		
	}

	public void lowerTriangular()
	{
		System.out.println("Lower Triangular Matrix is:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
	
	public void upperTriangular()
	{
		System.out.println("Upper Triangular Matrix is:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				if(j<i)
				{
					
					System.out.print("\t");
				}
				else
					System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
	
	public void transpose() 
	{
		System.out.println("Upper Triangular Matrix is:");
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				if(i<=j)
				{
					System.out.print(arr[j][i]+"\t");
				}
				else
				{	
					System.out.print(arr[j][i]+"\t");
				}
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		
		ArrayProblems a=new ArrayProblems();
		a.getSize();
		if(a.row==a.col)
		{
			a.getElements();
			a.printElements();
			a.lowerTriangular();
			a.upperTriangular();
			a.transpose();
			
		}
		
		
		
	}

	
}
