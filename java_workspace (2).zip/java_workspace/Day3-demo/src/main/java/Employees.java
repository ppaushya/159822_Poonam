
 
import java.util.Scanner;
 
public class Employees {
	Scanner sc=new Scanner(System.in);
	String fname;
	String lname;
	int age;
	int salary;
	public void getDetails()
	{
		System.out.println("Enter first name: ");
		fname=sc.nextLine();
		System.out.println("Enter last name: ");
		lname=sc.nextLine();
		System.out.println("Enter age: ");
		age=sc.nextInt();
		System.out.println("Enter salary: ");
		salary=sc.nextInt();
	}
	public void printDetails()
	{
		System.out.println("First name: "+fname);
		System.out.println("Last name: "+lname);
		System.out.println("Age: "+age);
		System.out.println("Salary: "+salary);
	}
	
	
public static void main(String[] args) {
 
		Employees[] emp=new Employees[2];
		for(int i=0;i<emp.length;i++)
		{
 
			emp[i]=new Employees();
		}
		System.out.println("Enter the employee details: ");
		for(int i=0;i<emp.length;i++)
		{
			emp[i].getDetails();
 
		}
		System.out.println("The employee details are: ");
		for(int i=0;i<emp.length;i++)
		{
 
			emp[i].printDetails();
		}
		for(int i=0;i<emp.length;i++)
		{
			for(int j=i;j<emp.length-1;j++)
			{
				if(emp[i].age>emp[j+1].age)
				{
					Employees a=emp[i];
					emp[i]=emp[j+1];
					emp[j+1]=a;
				}
			}
		}
 
	}
}




/*public class Employees {
	
	int employeeId;
	String[] firstName;
	String[] lastName;
	int age;
	int salary;
	

	public static void main(String[] args) {
		
		Employees[] employee=new Employees();
	}

}*/



