
public class TestArray {

	public static void main(String[] args) {
		//int[] num;//= new int[10];
		
		int[] num= {2,3,4,5,6};
		System.out.println("size:"+num.length);
		
		//double pi=3.14;
		
		short number=90;
		num[0]=1;
		num[1]=number;
		//num[5]=67;
		//num[7]=46;
		//num[8]=(int)pi;
		
		for(int i=0;i<num.length;i++)
			System.out.println(num[i]);
	}

}
