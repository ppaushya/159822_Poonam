import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;
import java.util.Vector;


public class CollectionDemo {

	public static void main(String[] args) {
	
		ArrayList<String> lst= new ArrayList<>();
		//Vector<String> lst= new Vector<>();
		lst.add("tyom");
		lst.add("jerry");
		lst.add("null");
		lst.add("poonam");
		lst.add("ojha");
		lst.add("null");
		for(String str:lst)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		
		ArrayList<String> l1=new ArrayList<>();
		l1.add("hi");
		l1.add("hello");
		l1.add("null");
		for(String str:l1)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		
		lst.addAll(l1);
		for(String str:lst)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		int size=lst.size();
		System.out.println(size);
		boolean out=lst.contains("tyom");
		System.out.println(out);
		lst.clear();
		for(String str:lst)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		boolean check=lst.isEmpty();
		System.out.println(check);


		System.out.println(l1.get(0));
		
		Object[] arr=new Object[l1.size()];
		
		arr=l1.toArray();
		for(Object str:arr)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		
		lst.add(0, "tom");
		lst.add("null");
		lst.add(2,"jerry");
		for(String str:lst)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		ArrayList<String> l2=new ArrayList<>();
		l2=(ArrayList<String>) l1.clone();
		for(String str:l2)
		{
			System.out.print(str+",");
			
		}
		boolean b=l2.containsAll(l1);
		System.out.println(b);
		
		l1.ensureCapacity(100);
		System.out.println(l1.size());
		l2.add("hey");
		boolean c=l2.containsAll(l1);
		System.out.println(c);
		System.out.println(l2.equals(l1));
		System.out.println(l2.indexOf("null"));
		System.out.println(l2.lastIndexOf("hello"));
		System.out.println(l2.listIterator(0));
		l2.remove(2);
		for(String str:l2)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		l2.removeAll(l2);
		for(String str:l2)
		{
			System.out.print(str+",");
			
		}
		
		ArrayList<String> l3= new ArrayList<>();

		
		l1.set(0, "tom");
		for(String str:l1)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		

		
		Spliterator<String> spliterator=l1.spliterator();
		System.out.println(spliterator.SIZED);

		l1.trimToSize();
		System.out.print(l1.size());


		
		l1.add(2, "yo");
		l1.add(3,"yo");
		l3=(ArrayList<String>) l1.subList(1, 2);
		System.out.print(l3);

		
		
		
		
/*
		//Enhanced for loop
		for(String str:lst)
		{
			System.out.print(str+",");
			
		}
		System.out.println();
		
		
		//Iterator 
		Iterator<String> iterator=lst.iterator();
		while(iterator.hasNext())
		{
			String str=iterator.next();
			System.out.print(str+",");
		}
		System.out.println();
		
		
		//List Iterator via this we can travel only three classes: Arraylist,Linked list and vector
		ListIterator<String>lstIterator=lst.listIterator();
		while(lstIterator.hasNext())
		{
			String s=lstIterator.next();
			System.out.print(s+"-->");

		}
		System.out.println();
		
		while(lstIterator.hasPrevious())
		{
			String s=lstIterator.previous();
			System.out.print(s+"<--");

		}
		System.out.println();
		
		
		//enumeration
		Enumeration <String> enumeration=lst.elements();
		while(enumeration.hasMoreElements())
		{
			String str=enumeration.nextElement();
			System.out.print(str+"-->");
		}
		
		*/
	}

}
