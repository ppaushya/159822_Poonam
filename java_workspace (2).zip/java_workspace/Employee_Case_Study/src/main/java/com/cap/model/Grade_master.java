package com.cap.model;

public class Grade_master {
	
	private String gradeCode;
	private String description;
	private int minSalary;
	private int maxSalary;
	public Grade_master(String gradeCode, String description, int minSalary, int maxSalary) {
		super();
		this.gradeCode = gradeCode;
		this.description = description;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
	}
	public Grade_master() {
		super();
	}
	public String getGradeCode() {
		return gradeCode;
	}
	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getMinSalary() {
		return minSalary;
	}
	public void setMinSalary(int minSalary) {
		this.minSalary = minSalary;
	}
	public int getMaxSalary() {
		return maxSalary;
	}
	public void setMaxSalary(int maxSalary) {
		this.maxSalary = maxSalary;
	}
	@Override
	public String toString() {
		return "Grade_master [gradeCode=" + gradeCode + ", description=" + description + ", minSalary=" + minSalary
				+ ", maxSalary=" + maxSalary + "]";
	}
	
	

}
