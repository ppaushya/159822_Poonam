package org.cap.demo;

public class MainMultiply {

	public static void main(String[] args) {

		MultiplicationTableThread t1= new MultiplicationTableThread("Thread 1",13);
		MultiplicationTableThread t2= new MultiplicationTableThread("Thread 2",15);
		MultiplicationTableThread t3= new MultiplicationTableThread("Thread 3",21);
		t1.run();
		
		t1.setPriority(10);
		System.out.println(t1.getPriority());
		t2.run();
		
		t3.run();
		
	}

}
