package org.cap.demo;

public class ThreadDemoRunnable implements Runnable{

	@Override
	public void run() {

		for(int i=1;i<=10;i++)
		{
			/*try {
				//delay in processing
				Thread.sleep(1000);*/
				System.out.println(Thread.currentThread().getName()+"---> "+i);
			/*} catch (InterruptedException e) {
				
				
				e.printStackTrace();
			}
			*/
		}
		
		
	}

}
