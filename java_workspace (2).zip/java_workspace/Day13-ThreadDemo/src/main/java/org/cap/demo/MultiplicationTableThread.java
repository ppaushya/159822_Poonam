package org.cap.demo;

public class MultiplicationTableThread extends Thread{
	
	private String name;
	private int x;
	
	
	public MultiplicationTableThread() {
		super();
	}
	public MultiplicationTableThread(String name, int x) {
		super();
		this.name=name;
		this.x=x;
	}

	@Override
	synchronized public void run()
	{
		printTable(x);
	}

	private void printTable(int x) {
		
		System.out.println("Table of "+x);
		for(int i=0;i<=10;i++)
		{
			System.out.println(getName()+" "+x+" x "+i+" = "+x*i);
		}
		
	}
	
}
