package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		
		
		
		MyThreadFromThreadClass t1= new MyThreadFromThreadClass();
		MyThreadFromThreadClass t2= new MyThreadFromThreadClass("capg thread");
		MyThreadFromThreadClass t3= new MyThreadFromThreadClass();
		t1.start();
		t2.start();
		t3.start();
		//start method will call the run method internally
	}

}
