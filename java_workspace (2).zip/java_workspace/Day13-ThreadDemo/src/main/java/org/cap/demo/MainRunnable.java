package org.cap.demo;

public class MainRunnable {

	
	public static void main(String[] args) {
		//create a reference for class
		ThreadDemoRunnable runnable= new ThreadDemoRunnable();
		//then pass it into the thread
		Thread t1= new Thread(runnable,"capg1");
		Thread t2= new Thread(runnable, "capg2");
		Thread t3= new Thread(runnable,"capg3");
		t3.start();
		
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t2.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
		
		
}
