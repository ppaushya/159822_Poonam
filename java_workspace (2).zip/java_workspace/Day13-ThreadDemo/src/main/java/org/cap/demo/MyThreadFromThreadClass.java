package org.cap.demo;

public class MyThreadFromThreadClass extends Thread {
	
	public MyThreadFromThreadClass() {
		
		super();
	}
	
	
	public MyThreadFromThreadClass(String threadName) {
		
		super(threadName);
	}
	
	
	@Override
	public void run()
	{
		System.out.println(getName()+"--->Thread started......");
	}

}
