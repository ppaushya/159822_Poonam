package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		
		//Capture the data from View
		String firstName=req.getParameter("firstName");
		String lastName=req.getParameter("lastName");
		String dateOfBirth=req.getParameter("dateOfBirth");
		System.out.println(dateOfBirth);
		String addressLine1=req.getParameter("addressline1");
		String addressLine2=req.getParameter("addressline2");
		String city=req.getParameter("city");
		String state=req.getParameter("state");
		String pincode=req.getParameter("pincode");
		String emailId=req.getParameter("emailId");
		String mobileNumber=req.getParameter("mobile");
		String password=req.getParameter("cutomerPwd");
		
		//Convert the input into Model
		Customer customer= new Customer();
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		String[] dateParts= dateOfBirth.split("-");
		customer.setDateOfBirth(LocalDate.of(Integer.parseInt(dateParts[0]),
				Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[2])));
		Address address=new Address();
		address.setAddressLine1(addressLine1);
		address.setAddressLine2(addressLine2);
		address.setCity(city);
		address.setState(state);
		address.setPinCode(pincode);
		customer.setAddress(address);
		customer.setEmailId(emailId);
		customer.setMobileNumber(mobileNumber);
		customer.setPassword(password);
		
		
		
		
		//Call Your business Logic
		//Navigate to next page
		
		
		
		if(loginService.createCustomer(customer))
		{	System.out.println("Record Inserted...");
			resp.sendRedirect("success");
		}
		else
			resp.sendRedirect("registration.html");
		
		
	}

	
}
