package org.capg.service;

import org.capg.model.Customer;
import org.capg.model.LoginBean;

public interface ILoginService {
	
	public boolean isValidLogin(LoginBean loginBean);

	public boolean createCustomer(Customer customer);

}
