package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.Calculator")
public class CalculatorImpl implements Calculator{

	@Override
	public int addNumber(int num1, int num2) {
		
		return num1+num2;
	}
	

} 