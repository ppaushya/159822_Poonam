package org.capg.dao;

public class CustomerDaoImpl {

}
