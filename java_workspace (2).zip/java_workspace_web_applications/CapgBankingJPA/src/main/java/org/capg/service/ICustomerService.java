package org.capg.service;

public interface ICustomerService {

}
