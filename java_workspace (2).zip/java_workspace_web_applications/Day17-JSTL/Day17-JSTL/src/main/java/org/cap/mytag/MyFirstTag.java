package org.cap.mytag;

import java.io.IOException;
//import java.io.StringWriter;
import java.time.LocalTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyFirstTag extends SimpleTagSupport{
	
	private String user;
	private String color;
	
	

	public void setUser(String user) {
		this.user = user;
	}



	public void setColor(String color) {
		this.color = color;
	}



	@Override
	public void doTag() throws JspException, IOException {
		
		JspWriter out= getJspContext().getOut();
		String user1 = new String();
		String color= new String(this.color);
		
		if(user!=null)
			user1= new String(user);
		else
			user1= new String("Capgemini!!");
		
		
		if(LocalTime.now().isBefore(LocalTime.of(12, 0)))
			out.println("<h3>Hello! Good Morning <span style='color:"+color+";'>"+user1+" </h3></span>");
		if(LocalTime.now().isAfter(LocalTime.of(12, 0)))
			out.println("<h3>Hello! Good Afternoon <span style='color:"+color+";'>"+user1+" </h3></span>");
		if(LocalTime.now().isAfter(LocalTime.of(18, 0)))
			out.println("<h3>Hello! Good Evening <span style='color:"+color+";'>"+user1+" </h3></span>");
	}
	
	
	

}
