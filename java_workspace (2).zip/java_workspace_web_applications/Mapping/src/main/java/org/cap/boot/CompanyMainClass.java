package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.ManytoOne.Company;
import org.cap.ManytoOne.Employee;

public class CompanyMainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Company company= new Company(1,"Capg");
		
		
		Employee employee1= new Employee(100,"Tom");
		Employee employee2 = new Employee(101,"Sam");
		
		company.getEmployees().add(employee1);
		company.getEmployees().add(employee2);
		
		employee1.setCompany(company);
		employee2.setCompany(company);
		
		entityManager.persist(company);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		

		
		transaction.commit();
		
	}

}
