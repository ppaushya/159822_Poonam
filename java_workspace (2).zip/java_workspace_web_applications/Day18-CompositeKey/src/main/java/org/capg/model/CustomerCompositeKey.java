package org.capg.model;

import java.io.Serializable;

import javax.persistence.Entity;

public class CustomerCompositeKey implements Serializable{

	private String custoemrId;
	private String userId;
	
	public CustomerCompositeKey() {
		
	}
	
	public CustomerCompositeKey(String custoemrId, String userId) {
		
		this.custoemrId = custoemrId;
		this.userId = userId;
	}
	public String getCustoemrId() {
		return custoemrId;
	}
	public void setCustoemrId(String custoemrId) {
		this.custoemrId = custoemrId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "CustomerCompositeKey [custoemrId=" + custoemrId + ", userId=" + userId + "]";
	}
	
	
	
}
