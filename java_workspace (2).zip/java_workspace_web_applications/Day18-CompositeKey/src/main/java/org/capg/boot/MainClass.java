package org.capg.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.capg.model.Customer;
import org.capg.model.CustomerCompositeKey;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		 
			CustomerCompositeKey customerCompositeKey=new CustomerCompositeKey("Ask","10011");
			Customer customer =new Customer(customerCompositeKey,"poonam","ojha");
						
			entityManager.persist(customer);
			
						
					 
			 

		
		transaction.commit();
		

	}

}
