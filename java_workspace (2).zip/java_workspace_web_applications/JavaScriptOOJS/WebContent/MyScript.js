

var emp={ 'empId':1001,
			'firstName':"Poonam",
			'lastName':"Ojha"}
console.log(emp);
var myFunc=function(){
	
	for(key in emp){
		
		console.log(key+'-'+emp[key]);
	}
	
	console.log("Hello!! JAVASCRIPT");
}
myFunc()