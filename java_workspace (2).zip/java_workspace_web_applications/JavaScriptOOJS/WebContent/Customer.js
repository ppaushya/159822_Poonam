function createCustomer(){
	
	var customerId;
	var customerName;
	var salary;
	
	this.setCustomerId=function(Id){
		customerId=Id;
	}
	this.getCustomerId=function(customerId){
		return this.customerId;
	}
	
	this.setCustomerName=function(Name){
		customerName=Name;
	}
	this.getCustomerName=function(customerName){
		return this.customerName;
	}
	this.setSalary=function(sal){
		salary=sal;
	}
	this.getSalary=function(sal){
		return this.salary;
	}
	this.printDetails=function(){
		console.log(customerId+"-"+customerName+"-"+salary)
	}
	
	
	
}

var customer= new createCustomer()

//customer.printDetails();
customer.setCustomerId(100000);
customer.setCustomerName("poonam");
customer.setSalary(45000);
customer.printDetails(customer.getCustomerId(), customer.getCustomerName(),customer.getSalary());