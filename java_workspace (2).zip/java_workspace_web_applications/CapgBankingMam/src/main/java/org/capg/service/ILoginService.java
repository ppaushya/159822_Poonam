package org.capg.service;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public interface ILoginService {
	
	public Customer isValidLogin(LoginBean loginBean);
	public boolean createCustomer(Customer customer);
	public Account createAccount(Account account);
	public List<Account> chooseAccount(int customerId);
	public boolean depositWithdraw(Transaction txn);
	public List<Account> otherAccount(int customerId);
}
