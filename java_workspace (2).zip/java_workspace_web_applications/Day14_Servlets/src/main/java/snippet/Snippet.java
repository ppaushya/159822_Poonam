package snippet;

public class Snippet {
	<?xml version="1.0" encoding="UTF-8"?>
	<web-app xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
	         xmlns="http://java.sun.com/xml/ns/javaee" 
	         xsi:schemaLocation="http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd" 
	         id="WebApp_ID" version="2.5">
}

