package org.cap.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	
	@Id
	private int customerId;
	private String custName;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_fk")
	private Address address;
	
	public Customer() {
		
	}
	
	public Customer(int customerId, String custName) {
		super();
		this.customerId = customerId;
		this.custName = custName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", custName=" + custName + "]";
	}
	
	

}
