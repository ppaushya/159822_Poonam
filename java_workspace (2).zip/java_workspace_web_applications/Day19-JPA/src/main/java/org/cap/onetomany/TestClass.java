package org.cap.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
			Company capg=new Company();
			capg.setCompanyId(1001);
			capg.setCompanyName("Capgemini");
			
			Company tcs=new Company();
			tcs.setCompanyId(1002);
			tcs.setCompanyName("TATA Consulatancy Services");
			
			
			Employee tom=new Employee(11, "Tom", tcs);
			Employee jerry=new Employee(101, "jerry", tcs);
			Employee sam=new Employee(111, "sam", capg);
			Employee ram=new Employee(112, "ram", tcs);
			Employee jack=new Employee(12, "jack", capg);
			
			entityManager.persist(tcs);
			entityManager.persist(capg);
			entityManager.persist(tom);
			entityManager.persist(jerry);
			entityManager.persist(jack);
			entityManager.persist(sam);
			entityManager.persist(ram);
			
		
		transaction.commit();
		entityManager.close();
	}

}
