package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.model.LoginPojo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService {

	@Autowired
	private ILoginDao loginDao;
	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
			
		return loginDao.isValidLogin(loginPojo);
	}

}
