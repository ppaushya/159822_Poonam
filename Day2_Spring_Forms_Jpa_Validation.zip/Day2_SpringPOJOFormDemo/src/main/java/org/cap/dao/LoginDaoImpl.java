package org.cap.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.LoginPojo;
import org.springframework.stereotype.Repository;
@Repository
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	private EntityManager em;
	@Transactional
	@Override
	public boolean isValidLogin(LoginPojo loginPojo) {
		
		String sql="from LoginPojo where userName=:uname and userPassword=:upwd";
		
		Query query=em.createQuery(sql);
		query.setParameter("uname", loginPojo.getUserName());
		query.setParameter("upwd", loginPojo.getUserPassword());
		
		List<LoginPojo> list=query.getResultList();
		if(!list.isEmpty())
			return true;
		return false;
	}

	
}
