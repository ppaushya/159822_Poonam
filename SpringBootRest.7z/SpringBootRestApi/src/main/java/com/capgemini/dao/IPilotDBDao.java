package com.capgemini.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.model.Pilot;

@Repository("pilotDbDao")
@Transactional
public interface IPilotDBDao extends JpaRepository<Pilot,Integer> {

}
