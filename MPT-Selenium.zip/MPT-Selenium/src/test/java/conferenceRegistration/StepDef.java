package conferenceRegistration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webDriver;
	
	private WebElement webElement;
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver","C:\\selenium\\chromedriver.exe" );
		
		webDriver=new ChromeDriver();
	}

	@Given("^Conference Registration page$")
	public void conference_Registration_page() throws Throwable {
		webDriver.get("file:///D:/Users/poojha/Desktop/Conferencebooking/ConferenceRegistartion.html#");
		
	    Thread.sleep(1000); 
	}

	@When("^Title is not equal to \"(.*?)\"$")
	public void title_is_not_equal_to(String arg1) throws Throwable {
	   
		assertNotEquals("Conference Registration", "Conference Registartion");
	}

	@Then("^Stop test execution$")
	public void stop_test_execution() throws Throwable {
	    webDriver.quit();
	}

	@When("^Heading is not equal to \"(.*?)\"$")
	public void heading_is_not_equal_to(String arg1) throws Throwable {
	    
		String heading=webDriver.findElement(By.tagName("h4")).getText();
		assertNotEquals("Step 1: Personal Detail", heading);
	}

	@When("^First name is null$")
	public void first_name_is_null() throws Throwable {
		 webDriver.findElement(By.id("txtFirstName")).sendKeys("");
	}

	@When("^Next link is clicked$")
	public void next_link_is_clicked() throws Throwable {
		WebElement element=webDriver.findElement(By.tagName("a"));
		element.click();
	}

	@Then("^Alert box displays 'Please fill the First Name'$")
	public void alert_box_displays_Please_fill_the_First_Name() throws Throwable {
		String alert=webDriver.switchTo().alert().getText();
		assertEquals("Please fill the First Name", alert);
	    if(alert.equals("Please fill the First Name")) {
	    	System.out.println("True");
	    }
	    else 
	    	System.out.println("False");
	    Thread.sleep(1000); 
	    webDriver.quit();
	}

	@When("^Last name is null$")
	public void last_name_is_null() throws Throwable {
		webDriver.findElement(By.id("txtFirstName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtLastName")).sendKeys("");
		 
	}
	
	@Then("^Alert box displays 'Please fill the Last Name'$")
	public void alert_box_displays_Please_fill_the_Last_Name() throws Throwable {
		String alert=webDriver.switchTo().alert().getText();
		assertEquals("Please fill the Last Name", alert);
	    if(alert.equals("Please fill the Last Name")) {
	    	System.out.println("True");
	    }
	    else 
	    	System.out.println("False");
	    Thread.sleep(1000); 
	    webDriver.quit();
	}

	@When("^Email is null$")
	public void email_is_null() throws Throwable {
		webDriver.findElement(By.id("txtFirstName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtLastName")).sendKeys("Ojha");
	    webDriver.findElement(By.id("txtEmail")).sendKeys("");
	}
	
	@Then("^Alert box displays 'Please fill the Email'$")
	public void alert_box_displays_Please_fill_the_Email() throws Throwable {
		String alert=webDriver.switchTo().alert().getText();
		assertEquals("Please fill the Email", alert);
	    if(alert.equals("Please fill the Email")) {
	    	System.out.println("True");
	    }
	    else 
	    	System.out.println("False");
	    Thread.sleep(1000); 
	    webDriver.quit();
	}

	@When("^Contact No\\. is null$")
	public void contact_No_is_null() throws Throwable {
		webDriver.findElement(By.id("txtFirstName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtLastName")).sendKeys("Ojha");
	    webDriver.findElement(By.id("txtEmail")).sendKeys("poonam@gmail.com");
	    webDriver.findElement(By.id("txtPhone")).sendKeys("");
	}
	
	@Then("^Alert box displays 'Please fill the Contact No\\.'$")
	public void alert_box_displays_Please_fill_the_Contact_No() throws Throwable {
		String alert=webDriver.switchTo().alert().getText();
		assertEquals("Please fill the Contact No.", alert);
	    if(alert.equals("Please fill the Contact No.")) {
	    	System.out.println("True");
	    }
	    else 
	    	System.out.println("False");
	    Thread.sleep(1000); 
	    webDriver.quit();
	}

	@When("^Number of people attending is null$")
	public void number_of_people_attending_is_null() throws Throwable {
		webDriver.findElement(By.id("txtFirstName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtLastName")).sendKeys("Ojha");
	    webDriver.findElement(By.id("txtEmail")).sendKeys("poonam@gmail.com");
	    webDriver.findElement(By.id("txtPhone")).sendKeys("9915155124");
	}
	
	@Then("^Alert box displays 'Please fill the Number of people attending'$")
	public void alert_box_displays_Please_fill_the_Number_of_people_attending() throws Throwable {
		String alert=webDriver.switchTo().alert().getText();
		assertEquals("Please fill the Number of people attending", alert);
	    if(alert.equals("Please fill the Number of people attending")) {
	    	System.out.println("True");
	    }
	    else 
	    	System.out.println("False");
	    Thread.sleep(1000); 
	    webDriver.quit();
	}

	@Given("^Details are filled correctly$")
	public void details_are_filled_correctly() throws Throwable {
		webDriver.findElement(By.id("txtFirstName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtLastName")).sendKeys("Ojha");
	    webDriver.findElement(By.id("txtEmail")).sendKeys("poonam@gmail.com");
	    webDriver.findElement(By.id("txtPhone")).sendKeys("9915155124");
	    
	    Select dropDown= new Select(webDriver.findElement(By.name("size")));
		dropDown.selectByValue("two");
	    
	    webDriver.findElement(By.id("txtAddress1")).sendKeys("Dashmesh Nagar");
	    webDriver.findElement(By.id("txtAddress2")).sendKeys("Dhuri Line");
	    
	    Select dropDown1= new Select(webDriver.findElement(By.name("city")));
		dropDown1.selectByValue("Pune");
	    
		Select dropDown2= new Select(webDriver.findElement(By.name("state")));
		dropDown2.selectByValue("Maharashtra");
		
		WebElement radioBtn = webDriver.findElement(By.name("memberStatus"));
		 radioBtn.click();
	}

	@Then("^Alert box displays 'Personal details are validated' and click ok$")
	public void alert_box_displays_Personal_details_are_validated_and_click_ok() throws Throwable {
		String alert=webDriver.switchTo().alert().getText();
		assertEquals("Personal details are validated.", alert);
	    if(alert.equals("Personal details are validated.")) {
	    	System.out.println("True");
	    }
	    else 
	    	System.out.println("False");
	   
		Alert alert1=webDriver.switchTo().alert();
		 alert1.accept();
	}
	
	@Then("^Navigate to Payment Details page$")
	public void navigate_to_Payment_Details_page() throws Throwable {
		 webDriver.navigate().to("file:///D:/Users/poojha/Desktop/Conferencebooking/PaymentDetails.html");
		 Thread.sleep(1000);
		 webDriver.quit();
	}
	
	
}
