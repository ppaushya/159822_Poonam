package conferenceRegistration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webDriver;
	
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver","C:\\selenium\\chromedriver.exe" );
		
		webDriver=new ChromeDriver();	
	}

	@Given("^Conference Registration page$")
	public void conference_Registration_page() throws Throwable {
		webDriver.get("file:///D:/Users/poojha/Desktop/Conferencebooking/ConferenceRegistartion.html#");
		
	    Thread.sleep(1000);

	}

	@When("^Verify title of the page$")
	public void verify_title_of_the_page() throws Throwable {
		String title=webDriver.getTitle();
		assertEquals("Conference Registartion", title);
	}

	@When("^Verify heading of the page$")
	public void verify_heading_of_the_page() throws Throwable {
	  /* webDriver.findElement(By.xpath("/html/body/h4"));*/
	}

	@When("^Enter User details$")
	public void enter_User_details() throws Throwable {
	    webDriver.findElement(By.id("txtFirstName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtLastName")).sendKeys("Ojha");
	    webDriver.findElement(By.id("txtEmail")).sendKeys("poonam@gmail.com");
	    webDriver.findElement(By.id("txtPhone")).sendKeys("9915155124");
	    
	    Select dropDown= new Select(webDriver.findElement(By.name("size")));
		dropDown.selectByValue("two");
	    
	    webDriver.findElement(By.id("txtAddress1")).sendKeys("Dashmesh Nagar");
	    webDriver.findElement(By.id("txtAddress2")).sendKeys("Dhuri Line");
	    
	    Select dropDown1= new Select(webDriver.findElement(By.name("city")));
		dropDown1.selectByValue("Pune");
	    
		Select dropDown2= new Select(webDriver.findElement(By.name("state")));
		dropDown2.selectByValue("Maharashtra");
		
		WebElement radioBtn = webDriver.findElement(By.name("memberStatus"));
		 radioBtn.click();
		 
	}

	@When("^click next button$")
	public void click_next_button() throws Throwable {
	    
		WebElement element=webDriver.findElement(By.tagName("a"));
		element.click();
		
	}
	
	@Then("^Alert box displays \"(.*?)\"$")
	public void alert_box_displays(String arg1) throws Throwable {
	    Alert alert=webDriver.switchTo().alert();
	    alert.accept();
	}

	@Then("^Navigate to Payment Details page$")
	public void navigate_to_Payment_Details_page() throws Throwable {
	    webDriver.navigate().to("file:///D:/Users/poojha/Desktop/Conferencebooking/PaymentDetails.html");
	}


	@Given("^Payment Details page$")
	public void payment_Details_page() throws Throwable {
	    webDriver.navigate().to("file:///D:/Users/poojha/Desktop/Conferencebooking/PaymentDetails.html");

	}

	@When("^payment details entered$")
	public void payment_details_entered() throws Throwable {
	    webDriver.findElement(By.id("txtCardholderName")).sendKeys("Poonam");
	    webDriver.findElement(By.id("txtDebit")).sendKeys("123654789654");
	    webDriver.findElement(By.id("txtCvv")).sendKeys("456");
	    webDriver.findElement(By.id("txtMonth")).sendKeys("October");
	    webDriver.findElement(By.id("txtYear")).sendKeys("2019");
	    

	}

	@When("^Click Register button$")
	public void click_Register_button() throws Throwable {
		WebElement click=webDriver.findElement(By.id("btnPayment"));
		click.click();
	}

}
