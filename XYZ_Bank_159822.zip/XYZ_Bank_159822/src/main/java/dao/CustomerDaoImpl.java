package dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import model.Account;
import model.AccountType;
import model.Address;
import model.Customer;
import model.Transaction;

public class CustomerDaoImpl implements ICustomerDao{
	
	private static List<Customer> customers=dummyDb();
	//private static List<Transaction> transactions=new ArrayList<>();
	private static List<Customer> dummyDb(){
        List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123,"Jack","Thomson", LocalDate.of(1991, 01, 23),
				"jack@gmail.com","8890912345",address,new HashSet<Account>()));
		
		Address address1=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090,"Tom","Jerry", LocalDate.of(1987, 12, 23),
				"tom@gmail.com","9090912345",address1,new HashSet<Account>()));
		
		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		customers.add(customer);
	}
	public Customer isCustomerFound(int customerId)
	{
		for(Customer customer:getAllCustomers()) {
			if(customer.getCustomerId()==customerId)
				return customer;
		}
		return null;
		
	}
        @Override
        public Account isAccountFound(Customer customer,int accountNumber)
         {
             for(Account account:customer.getAccounts())
             {
                 if(account.getAccountNumber()==accountNumber)
                     return account;
             }
             return null;
         }
	public void AddAccount(Customer customer,Account account)
	{
		customer.getAccounts().add(account);
		//customer.setAccounts();
	}
        private static List<Transaction> transactions=new ArrayList<>();
        @Override
        public void addTransaction(Transaction transaction)
        {
            transactions.add(transaction);
            
        }
        @Override
        public List<Transaction> getAllTransaction()
        {
            return transactions;
        }
        @Override
        public double getCurrentBalance(Account account,int accountNumber)
        {
            double currentBalance=account.getOpeningBalance();
            for(Transaction transaction:getAllTransaction()) {
                if(transaction.getToAccount()!=null)
                {
		if(transaction.getToAccount().getAccountNumber() == accountNumber )
                {
                   if(transaction.getTransactionType().equals("Deposit"))
                   {
                       currentBalance+=transaction.getAmount();
                   }
                   else if(transaction.getTransactionType().equals("Fund Transfer") )
                   {
                       currentBalance+=transaction.getAmount();
                   }
                }
                }else if(transaction.getFromAccount()!=null)
                {
                 if(transaction.getFromAccount().getAccountNumber() == accountNumber)
                {
                    if(transaction.getTransactionType().equals("Withdrawal"))
                   {
                       currentBalance-=transaction.getAmount();
                   }
                   else if(transaction.getTransactionType().equals("Fund Transfer"))
                   {
                       currentBalance-=transaction.getAmount();
                   }
                }
                }
            }
            return currentBalance;
        }

}
