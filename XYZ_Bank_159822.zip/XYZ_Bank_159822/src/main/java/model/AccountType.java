package model;

public enum AccountType {
	
	SAVINGS,CURRENT,RD,FD;

}
