package org.capg.boot;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory emf= Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager= emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Set<Account> accounts=new HashSet<>();
		
		Customer customer= new Customer(1000,"POONAM","OJHA",null,"poonamojha96@gmail.com","9915155124",
				new Address("Dashmesh","Nagar","Ludhiana","Punjab","141003"));
		
		Address address=new Address("23,North East","Near Capgemini", "Chennai", "TN", "507302");
		customer.setAddress(address);
		Account account=new Account(123456,AccountType.CURRENT,null,500,"This is a current account");
		account.setOpeningDate(LocalDate.now());
		accounts.add(account);
		customer.setAccounts(accounts);
		
		
		entityManager.persist(account);
		entityManager.persist(address);
		entityManager.persist(customer);
		
		transaction.commit();

	}

}
