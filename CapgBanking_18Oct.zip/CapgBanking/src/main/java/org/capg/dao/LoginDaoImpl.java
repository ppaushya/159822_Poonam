package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public class LoginDaoImpl implements ILoginDao{

	


	@Override
	public Customer isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where emailId=? and customerPwd=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(rs.getInt(1));
				customer.setFirstName(rs.getString(2));
				customer.setLastName(rs.getString(3));
				return customer;
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = (Connection)DriverManager
				    .getConnection("jdbc:mysql://localhost:3306/mydb?useSSL=false", "root", "iamhappy");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "iamhappy");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		return conn;
		
	}


	@Override
	public boolean createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customer(firstName,lastName,dateOfBirth, emailId,mobile,customerPwd)"+
						" values(?,?,?,?,?,?)";
		
	try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
		
		pst.setString(1, customer.getFirstName());
		pst.setString(2, customer.getLastName());
		pst.setDate(3, Date.valueOf(customer.getDateOfBirth()));
		pst.setString(4, customer.getEmailId());
		pst.setString(5,customer.getMobile());
		pst.setString(6,customer.getCustomerPwd());	
		
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
		if(flag) {
			String sqlMax="select max(customerId) from customer";
			try(PreparedStatement pst1=getMysqlDbConnection().prepareStatement(sqlMax)) {
				ResultSet rs= pst1.executeQuery();
				if(rs.next())
					customerId=rs.getInt(1);
				
				
				String sqlAdd="insert into address(addressline1,addressline2,city,state,pincode,customerId) values(?,?,?,?,?,?)";
				
				try(PreparedStatement pst2=getMysqlDbConnection().prepareStatement(sqlAdd)) {
					pst2.setString(1, customer.getAddress().getAddressLine1());
					pst2.setString(2, customer.getAddress().getAddressLine2());
					pst2.setString(3, customer.getAddress().getCity());
					pst2.setString(4, customer.getAddress().getState());
					pst2.setString(5, customer.getAddress().getPincode());
					pst2.setInt(6, customerId);
					
					int count1=pst2.executeUpdate();
					if(count1>0)
						flag=true;
					else
						flag=false;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			flag=false;
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}


	@Override
	public Account createAccount(Account account) {
		
		Long accountNo=null;
		
		String sqlaccNum="select max(accountNumber) from account";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sqlaccNum)){
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				accountNo=Long.valueOf(rs.getInt(1));
				if(accountNo==0)
					accountNo=100000l;
				else
					accountNo+=1;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		account.setAccountNumber(accountNo);
		
		String sql="insert into account values(?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
			pst.setLong(1, accountNo);
			pst.setString(2, account.getAccountType().toString());
			pst.setDate(3,Date.valueOf(account.getOpeningDate()));
			pst.setDouble(4, account.getOpeningBalance());
			pst.setString(5, account.getDescription());
			pst.setInt(6, account.getCustomer().getCustomerId());
			int count=pst.executeUpdate();
			if(count>0)
				return account;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}


	@Override
	public List<Account> chooseAccount(int customerId) {
		
		List<Account> accounts=new ArrayList<>();
		
		String sql="select * from account where customerId=?";
		
			try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
				pst.setInt(1, customerId);
				
				ResultSet result=pst.executeQuery();
				
					while(result.next())
					{
						for(Account account:accounts)
						{
						account.setAccountNumber(result.getLong(1));
						account.setAccountType(AccountType.valueOf(result.getString(2)));
						account.setOpeningBalance(result.getInt(4));
						accounts.add(account);
						System.out.println(account);
						}
					
					}
				
				
					return accounts;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return null;
		
		
	}

}
