package login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webDriver;
	
	private WebElement webElement;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\selenium\\chromedriver.exe" );
		
		webDriver=new ChromeDriver();
		
	}

	@Given("^Open Gray Matter Banking login page$")
	public void open_Gray_Matter_Banking_login_page() throws Throwable {
		webDriver.get("http://localhost:8081/GrayMatterBanking/");
		//webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);
	
			

	}

	@Given("^Add username and password$")
	public void add_username_and_password() throws Throwable {
	    webDriver.findElement(By.name("userName")).
	    		sendKeys("vageeshdxeet@gmail.com");
	    webDriver.findElement(By.name("userPwd")).sendKeys("vageesh123");
	    //webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    Thread.sleep(1000);
	}

	@When("^Submit validate Login details$")
	public void submit_validate_Login_details() throws Throwable {
	    
		webElement=webDriver.findElement(By.name("login"));
		webElement.submit();
		//webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(1000);
	}

	@Then("^Navigate to MainPage$")
	public void navigate_to_MainPage() throws Throwable {
	    webDriver.navigate().to("http://localhost:8081/GrayMatterBanking/loginServlet");
	    //webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    Thread.sleep(1000);
	    
	}
	
	@After
	public void tearDown() {
		webDriver.quit();
	}
}
