package register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webDriver;
	
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver","C:\\selenium\\chromedriver.exe" );
		
		webDriver=new ChromeDriver();	
	}
	
	
	@Given("^Click on Sign up to register$")
	public void click_on_Sign_up_to_register() throws Throwable {
		webDriver.get("http://localhost:8081/GrayMatterBanking/");
		
		WebElement webElement=webDriver.findElement(By.className("btnStyle"));
		webElement.click();
	    Thread.sleep(1000);

	}

	@Given("^Add registration details$")
	public void add_registration_details() throws Throwable {
	   
		webDriver.findElement(By.name("firstName")).sendKeys("Damini");
		webDriver.findElement(By.name("lastName")).sendKeys("Gupta");
		webDriver.findElement(By.name("dateOfbirth")).sendKeys("01/11/1996");
		webDriver.findElement(By.name("addressline1")).sendKeys("APS");
		webDriver.findElement(By.name("addressline2")).sendKeys("School");
		
		Select dropDown= new Select(webDriver.findElement(By.name("city")));
		dropDown.selectByValue("Pune");
		
		/*WebElement element=webDriver.findElement(By.name("state"));
		element.findElement(By.id("Pune"));
		element.click();*/
		 WebElement radioBtn = webDriver.findElement(By.id("Maharashtra"));
		 radioBtn.click();
		webDriver.findElement(By.name("pincode")).sendKeys("141003");
		webDriver.findElement(By.name("email")).sendKeys("damini@gmail.com");
		webDriver.findElement(By.name("mobile")).sendKeys("9988776655");
		webDriver.findElement(By.name("custPwd")).sendKeys("damini123");
		webDriver.findElement(By.name("confimrCustPwd")).sendKeys("damini123");
	    Thread.sleep(1000);

	}

	@When("^On Submit validate registration details$")
	public void on_Submit_validate_registration_details() throws Throwable {
	    WebElement element= webDriver.findElement(By.name("register"));
	    element.submit();
	    Thread.sleep(1000);

	}

	@Then("^Navigate to Login page$")
	public void navigate_to_Login_page() throws Throwable {
	    
		webDriver.navigate().to("http://localhost:8081/GrayMatterBanking/index.html");
	    Thread.sleep(1000);

	}
	@After
	public void tearDown() {
		webDriver.quit();
	}

}
