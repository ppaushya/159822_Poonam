package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("pilotDbDao")
@Transactional
public interface IPilotDBDao extends JpaRepository<Pilot,Integer> {
	
	@Query("from Pilot p where p.salary>:minsalary and p.salary<:maxsalary")
	public List<Pilot> getAllPilotsWithSalary(double minsalary,double maxsalary);
	
	@Query("from Pilot p where p.pilotName like '%a%'")
	public List<Pilot>getAllPilotWithName();

}
