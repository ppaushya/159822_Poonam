package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.LoginPojo;
import org.cap.model.Register;
import org.springframework.stereotype.Repository;

@Repository("registerDao")
@Transactional
public class RegisterDaoImpl implements IRegisterDao {

	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	public void insertRegistration(Register register) {

		em.persist(register);
	}
	@Override
	public List<Register> getAllRegistration()
	{
		List<Register> registers= em.createQuery("from Register").getResultList();
		
		return registers;	
	}
	
	@Override
	public void deleteRegistration(int registrationId) {
		
		Register register= em.find(Register.class, registrationId);
	}
	
	@Override
	public Register findRegistration(int registrationId) {
		Register register= em.find(Register.class, registrationId);
		
		return register;
	}
	@Override
	public void updateRegistration(Register register) {
		
		em.merge(register);
	
	}

}
