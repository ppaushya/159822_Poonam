package org.cap.boot;

import org.cap.model.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		//abstract application context is class which also extends application context
		AbstractApplicationContext context= new ClassPathXmlApplicationContext("myBeans.xml");
		//one request
		Employee employee = (Employee) context.getBean("emp");
		//another request
		
		
		employee.setEmployeeName("JACK");
		
		System.out.println(employee);
		
		
		context.close();
		
	}

}
