package org.cap.service;


import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService {

	@Override
	public boolean isValidLogin(String userName, String userPassword) {
		
		if(userName.equals("tom")&&
				userPassword.equals("tom123"))
			return true;
		return false;
	}

	
}
