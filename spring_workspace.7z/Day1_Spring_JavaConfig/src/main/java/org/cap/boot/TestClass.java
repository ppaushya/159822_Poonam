package org.cap.boot;

import org.cap.config.JavaConfig;
import org.cap.config.MyConfig;
import org.cap.model.Employee;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class TestClass {

	public static void main(String[] args) {
AbstractApplicationContext context= new AnnotationConfigApplicationContext(MyConfig.class);
		
		String greet= context.getBean(String.class);
		Integer ui=context.getBean(Integer.class);
		
		Employee employee= context.getBean(Employee.class);
		
		System.out.println(greet);
		System.out.println(ui);
		System.out.println(employee);
		

	}

}
