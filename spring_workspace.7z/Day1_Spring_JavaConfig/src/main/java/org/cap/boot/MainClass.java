package org.cap.boot;

import org.cap.config.JavaConfig;
import org.cap.model.Employee;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class MainClass {

	public static void main(String[] args) {


		AbstractApplicationContext context= new AnnotationConfigApplicationContext(JavaConfig.class);
		
		Employee employee= context.getBean(Employee.class);
		
		Employee employee1= context.getBean(Employee.class);
		
		employee1.setEmployeeName("tom");
		
		System.out.println(employee);
		System.out.println(employee1);
		
		context.close();
	}

}
