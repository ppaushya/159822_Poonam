package org.cap.config;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {

	@Bean
	//@Scope("prototype")
	public Employee getEmployeeBean() {
		return new Employee(12,"poonam",45678);
		
	}
	@Bean(name="address2")
	public Address getAddressBean() {
		return new Address("dashmesh","nagar");
	}
	
	@Bean (name="address1")
	public Address getAddressBean1() {
		return new Address("ludhiana","punjab");
	}
}
