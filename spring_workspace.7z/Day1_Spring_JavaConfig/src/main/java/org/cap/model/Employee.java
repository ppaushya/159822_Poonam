package org.cap.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private float employeeSalary;
	
	@Autowired
	@Qualifier("address1")
	private Address address;
	
	public Employee() {
		System.out.println(" Employee Constructor with no arguments");
		
	}
	

	

	public Employee(int employeeId, String employeeName, float employeeSalary) {
		super();
		System.out.println(" Employee Constructor with 3 arguments");
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}




	public Address getAddress() {
		return address;
	}




	public void setAddress(Address address) {
		this.address = address;
	}




	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + ", address=" + address + "]";
	}




	public Employee(int employeeId, String employeeName, float employeeSalary, Address address) {
		super();
		System.out.println(" Employee Constructor with 4 arguments");
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
		this.address = address;
	}




	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public float getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	@PostConstruct
	public void setUp(){
		System.out.println("Employee Bean Initialized");
	}
	
	@PreDestroy
	public void destroy_method(){
		System.out.println("Employee Bean destroyed");
	}
	
	

}
