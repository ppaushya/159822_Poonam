package org.xyz.dao;

import java.util.List;
import java.util.Set;

import org.xyz.modal.Account;
import org.xyz.modal.Customer;


public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);
	public void createAccount(Account account);
	public Set<Account> getAllAccounts(Customer customer);


}
