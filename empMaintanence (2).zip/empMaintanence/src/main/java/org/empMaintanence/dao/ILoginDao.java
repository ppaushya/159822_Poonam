package org.empMaintanence.dao;

import java.util.List;

import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public interface ILoginDao {

	boolean validlogin(UserMaster usermaster);

	public void addEmployeeDetails(Employee employee);

	void modifyfirstname();

	public List<Department> displayDepartmentList();

}
