package org.empMaintanence.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;


public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean validlogin(UserMaster usermaster) {
		// TODO Auto-generated method stub
		
		
		if(usermaster.getUserType().compareTo("admin")==0 || usermaster.getUserType().compareTo("ADMIN")==0 )
		{
			if(usermaster.getUserId().compareTo("100")==0 && usermaster.getUserName().compareTo("mainadmin")==0 && usermaster.getUserPassword().compareTo("admin123")==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else if(usermaster.getUserType().compareTo("employee")==0 || usermaster.getUserType().compareTo("EMPLOYEE")==0 )
		{
		   	 
		}
				
		return false;
	}
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/casestudy", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}


	@Override
	public void addEmployeeDetails(Employee employee) {
		// TODO Auto-generated method stub
       
		String sql="insert into employee(emp_Id,emp_First_Name,emp_Last_Name,emp_Date_Of_Birth,Emp_Date_Of_Joining,"
				+ "Emp_dept_id,Emp_Grade,Emp_designation,Emp_Basic,Emp_Gender,Emp_Marital_status,"
				+ "Emp_home_Address,Emp_contact_Num) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, employee.getEmpId());
			  pst.setString(2, employee.getEmpFirstName());
			  pst.setString(3, employee.getEmpLastName());
			  pst.setDate(4, Date.valueOf(employee.getEmpDateOfBirth()));
			  pst.setDate(5, Date.valueOf(employee.getEmpDateOfJoining()));
			  pst.setInt(6, employee.getEmpDeptId());
			  pst.setString(7, employee.getEmpGrade());
			  pst.setString(8, employee.getEmpDesignation());
			  pst.setInt(9, employee.getEmpBasic());
			  pst.setString(10, employee.getEmpGender());
			  pst.setString(11, employee.getEmpMaritalStatus());
			  pst.setString(12, employee.getEmpHomeAddress());
			  pst.setString(13, employee.getEmpContactNo());
			  
			  int count=pst.executeUpdate();
			  
			  if(count>0)
			  {
				  System.out.println("record inserted");
			  }
			  
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


		  

	}


	@Override
	public void modifyfirstname() {
		// TODO Auto-generated method stub
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter the employee id");
		
		int empid=scanner.nextInt();
		
		System.out.println("Enter the name you want to replace with");
		
		String replaceName=scanner.next();
		
		String sql="update employee set emp_First_Name=? where emp_Id=?";
		
		
		  try(Connection conn=getDbConnection())
		  {
			  PreparedStatement pst=conn.prepareStatement(sql);
			  
			  pst.setString(1, replaceName);
			  pst.setInt(2, empid);

			  pst.execute();
			  
			  
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public List<Department> displayDepartmentList() {
		
		List<Department> departments= new ArrayList<>();
		
		String sql="select * from Department";
		
		try(Connection conn=getDbConnection())
		  {
			  try {
				PreparedStatement pst=conn.prepareStatement(sql);
				
				ResultSet rs= pst.executeQuery();
				
				while(rs.next())
				{
					Department dept= new Department();
					
					dept.setDeptId(rs.getInt(1));
					dept.setDeptName(rs.getString(2));
					
					departments.add(dept);
					
				}
				
				return departments;
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  } catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return null;
	}

}
