package org.empMaintanence.service;

import java.util.List;

import org.empMaintanence.model.Department;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public interface ILoginService {

	boolean validlogin(UserMaster usermaster);

	void addEmployeeDetails(Employee employee);

	void modifyfirstname();
	
	public List<Department> displayDepartmentList();

	
	
	
}
