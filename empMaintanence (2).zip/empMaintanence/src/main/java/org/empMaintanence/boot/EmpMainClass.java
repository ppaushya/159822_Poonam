package org.empMaintanence.boot;

import java.util.Scanner;

import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.service.ILoginService;
import org.empMaintanence.service.LoginServicesImpl;
import org.empMaintanence.view.UserInteraction;

public class EmpMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner=new Scanner(System.in);
		
		boolean flag=true;
		
		ILoginService loginservices=new LoginServicesImpl();
		
		UserInteraction userinteraction=new UserInteraction();
		
		UserMaster usermaster=userinteraction.getLoginDetails();
		
		if(loginservices.validlogin(usermaster))
		{
	      System.out.println("valid login");	
	      
	      while(flag)
	      {
	           System.out.println("1.Add Employee");
	           System.out.println("2.Modify Employee details");
	           System.out.println("3.Display Employees list");
	           
	           int ch=scanner.nextInt();
	           
	           if(ch==1)
	           {
	        	   Employee employee=userinteraction.addEmployeeDetails();
	                    
	        	   loginservices.addEmployeeDetails(employee);   
	           }
	           else if(ch==2)
	           {
	        	  
	        	   System.out.println("1.modify first name");
	        	   System.out.println("2.modify last name");
	        	   System.out.println("3.modify date of birth");
	        	   System.out.println("4.modify date of joining");
	        	   System.out.println("5.modify department id");
	        	   System.out.println("6.modify employee grade");
	        	   System.out.println("7.modify employee designation");
	        	   System.out.println("8.modify employee basic");
	        	   System.out.println("9.modify employee gender");
	        	   System.out.println("10.modify employee marital status");
	        	   System.out.println("11.modify employee home address");
	        	   System.out.println("12.modify employee contact no");
	        	   
	        	   int ch2=scanner.nextInt();
	        	   
	        	   if(ch2==1)
	        	   {
	        		   loginservices.modifyfirstname();
	        	   }
	           }
	      }
	      
	      
	      
		}
		else
		{
			System.out.println("Invalid Credentials");
		}
		
		
		
		
	}

}



